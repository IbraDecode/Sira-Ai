module.exports = {
  BOT_TOKEN: '8430869382:AAEKYcGt1GboMBVwbw--q87NDiYSSeEYIvA', 
  OWNER_ID: ['6924389613']
};
